import { Users as UsersIcon } from 'lucide-react'
import ComingSoon from '../../components/ComingSoon'

export default function Users() {
  return (
    <ComingSoon
      icon={UsersIcon}
      title="User management will be available here"
      description="Viewing Basseer accounts and managing admin roles is a separate task, built on the admin_roles foundation already in place."
    />
  )
}
