-- Minor hardening of the function just added in hospital_management_foundation.
-- Not a change to any pre-existing object — basseer_hospitals_sync_city_text
-- was created in the previous migration moments ago.
create or replace function public.basseer_hospitals_sync_city_text()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  select name into new.city
  from public.cities
  where id = new.city_id;

  if new.city is null then
    raise exception
      'hospitals.city_id % does not reference an existing cities row',
      new.city_id;
  end if;

  return new;
end;
$$;
