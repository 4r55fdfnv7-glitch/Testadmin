import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, ChevronUp, ChevronDown, Eye, EyeOff } from 'lucide-react'
import type { ContentCategory, Audience } from '../../../types/content'
import { AUDIENCE_LABELS } from '../../../types/content'
import * as api from '../../../lib/contentApi'
import Modal from '../../../components/Modal'
import ConfirmDialog from '../../../components/ConfirmDialog'
import CategoryForm from '../../../components/content/CategoryForm'

const AUDIENCES: Audience[] = ['parent', 'child', 'both']

export default function CategoriesPanel() {
  const [categories, setCategories] = useState<ContentCategory[]>([])
  const [itemCounts, setItemCounts] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const [formState, setFormState] = useState<
    { mode: 'add'; audience: Audience } | { mode: 'edit'; category: ContentCategory } | null
  >(null)
  const [deleteTarget, setDeleteTarget] = useState<ContentCategory | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      const [cats, counts] = await Promise.all([api.listCategories(), api.countItemsByCategory()])
      setCategories(cats)
      setItemCounts(counts)
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load categories.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  async function handleToggleActive(category: ContentCategory) {
    setBusyId(category.id)
    try {
      await api.updateCategory(category.id, { is_active: !category.is_active })
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not update category.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleMove(list: ContentCategory[], index: number, direction: -1 | 1) {
    const other = list[index + direction]
    if (!other) return
    const current = list[index]
    setBusyId(current.id)
    try {
      await api.swapCategoryOrder(current, other)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not reorder categories.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    setDeleteError(null)
    try {
      await api.deleteCategory(deleteTarget.id)
      setDeleteTarget(null)
      await load()
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Could not delete category.')
    } finally {
      setDeleting(false)
    }
  }

  async function handleFormSubmit(values: Parameters<typeof api.createCategory>[0]) {
    if (formState?.mode === 'edit') {
      await api.updateCategory(formState.category.id, values)
    } else {
      await api.createCategory(values)
    }
    setFormState(null)
    await load()
  }

  if (loading) {
    return <p className="text-sm text-ink-muted">Loading categories…</p>
  }

  return (
    <div className="space-y-8">
      {loadError && (
        <div className="rounded-lg border border-danger/20 bg-danger-soft px-4 py-3 text-sm text-danger">
          {loadError}
        </div>
      )}

      {AUDIENCES.map((audience) => {
        const group = categories.filter((c) => c.audience === audience)
        return (
          <div key={audience}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-bold text-ink">{AUDIENCE_LABELS[audience]}</h3>
              <button
                type="button"
                onClick={() => setFormState({ mode: 'add', audience })}
                className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-ink hover:bg-canvas"
              >
                <Plus size={14} />
                Add category
              </button>
            </div>

            {group.length === 0 ? (
              <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-6 text-center text-sm text-ink-faint">
                No categories for {AUDIENCE_LABELS[audience].toLowerCase()} yet.
              </p>
            ) : (
              <div className="overflow-hidden rounded-xl border border-border bg-surface">
                <table className="w-full text-sm">
                  <tbody>
                    {group.map((category, index) => {
                      const count = itemCounts[category.id] ?? 0
                      const isBusy = busyId === category.id
                      return (
                        <tr
                          key={category.id}
                          className={`border-b border-border last:border-0 ${isBusy ? 'opacity-50' : ''}`}
                        >
                          <td className="w-16 px-3 py-3">
                            <div className="flex flex-col items-center gap-0.5">
                              <button
                                type="button"
                                disabled={index === 0 || isBusy}
                                onClick={() => handleMove(group, index, -1)}
                                className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                                aria-label="Move up"
                              >
                                <ChevronUp size={16} />
                              </button>
                              <button
                                type="button"
                                disabled={index === group.length - 1 || isBusy}
                                onClick={() => handleMove(group, index, 1)}
                                className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                                aria-label="Move down"
                              >
                                <ChevronDown size={16} />
                              </button>
                            </div>
                          </td>
                          <td className="px-2 py-3">
                            <p dir="auto" className="font-medium text-ink">
                              {category.name}
                            </p>
                            {category.description && (
                              <p dir="auto" className="mt-0.5 text-xs text-ink-faint">
                                {category.description}
                              </p>
                            )}
                            <p className="mt-0.5 text-xs text-ink-faint">
                              {count} content item{count === 1 ? '' : 's'}
                            </p>
                          </td>
                          <td className="px-2 py-3">
                            <span
                              className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                                category.is_active
                                  ? 'bg-success-soft text-success'
                                  : 'bg-canvas text-ink-faint'
                              }`}
                            >
                              {category.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="px-2 py-3 text-right">
                            <div className="flex justify-end gap-1">
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => handleToggleActive(category)}
                                title={category.is_active ? 'Deactivate' : 'Activate'}
                                className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                              >
                                {category.is_active ? <EyeOff size={15} /> : <Eye size={15} />}
                              </button>
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => setFormState({ mode: 'edit', category })}
                                title="Edit"
                                className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                              >
                                <Pencil size={15} />
                              </button>
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => {
                                  setDeleteError(null)
                                  setDeleteTarget(category)
                                }}
                                title={count > 0 ? `Has ${count} content item(s) — deactivate instead, or delete/move them first` : 'Delete'}
                                className="rounded-md p-1.5 text-ink-muted hover:bg-danger-soft hover:text-danger"
                              >
                                <Trash2 size={15} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )
      })}

      {formState && (
        <Modal
          title={formState.mode === 'edit' ? 'Edit category' : 'Add category'}
          onClose={() => setFormState(null)}
        >
          <CategoryForm
            initial={formState.mode === 'edit' ? formState.category : null}
            defaultAudience={formState.mode === 'add' ? formState.audience : undefined}
            nextSortOrder={
              1 +
              Math.max(
                0,
                ...categories
                  .filter((c) => c.audience === (formState.mode === 'add' ? formState.audience : formState.category.audience))
                  .map((c) => c.sort_order),
              )
            }
            onSubmit={handleFormSubmit}
            onCancel={() => setFormState(null)}
          />
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete category?"
          message={
            (itemCounts[deleteTarget.id] ?? 0) > 0
              ? `"${deleteTarget.name}" still has ${itemCounts[deleteTarget.id]} content item(s). Deleting is blocked while that's true — move or delete those items first, or deactivate the category instead.`
              : `This permanently deletes "${deleteTarget.name}". This can't be undone.`
          }
          confirmLabel="Delete"
          danger
          busy={deleting}
          errorMessage={deleteError}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  )
}
