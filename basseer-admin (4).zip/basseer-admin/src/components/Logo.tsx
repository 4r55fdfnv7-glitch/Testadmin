interface LogoMarkProps {
  size?: number
  className?: string
}

/**
 * The one deliberate signature element in this UI: a focusing aperture,
 * echoing what "Basseer" (بصير — "one who sees clearly") means. Reused at
 * different sizes for the sidebar mark, the login screen, and empty states,
 * instead of introducing a second decorative motif.
 */
export function LogoMark({ size = 28, className = '' }: LogoMarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <circle cx="16" cy="16" r="15" stroke="currentColor" strokeOpacity="0.16" strokeWidth="2" />
      <circle cx="16" cy="16" r="9.5" stroke="currentColor" strokeWidth="2" />
      <path
        d="M16 16 L16 6.5 A9.5 9.5 0 0 1 24.2 11.3 Z"
        fill="currentColor"
      />
      <circle cx="16" cy="16" r="2.5" fill="currentColor" />
    </svg>
  )
}
