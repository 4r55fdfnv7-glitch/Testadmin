import { useState } from 'react'
import { ShieldAlert } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import CategoriesPanel from './content/CategoriesPanel'
import ItemsPanel from './content/ItemsPanel'
import TipsPanel from './content/TipsPanel'

type Tab = 'categories' | 'items' | 'tips'

export default function Content() {
  const { hasRole, isSuperAdmin } = useAuth()
  const [tab, setTab] = useState<Tab>('categories')

  const canManageContent = isSuperAdmin || hasRole('content_editor')

  if (!canManageContent) {
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center rounded-xl border border-dashed border-border bg-surface px-6 py-16 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning-soft text-warning">
          <ShieldAlert size={22} />
        </div>
        <h2 className="mt-4 text-lg font-bold text-ink">Content Editor access required</h2>
        <p className="mt-1.5 max-w-sm text-sm text-ink-muted">
          Your account doesn't have the content_editor or super_admin role, so you can't manage
          the Content Library from here. Ask a super admin if you need access.
        </p>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6">
        <h1 className="text-xl font-bold tracking-tight text-ink">Content Library</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Changes here appear in the Basseer app automatically — publishing or activating
          something makes it visible right away, no app update needed.
        </p>
      </div>

      <div className="mb-6 flex gap-1 border-b border-border">
        <button
          type="button"
          onClick={() => setTab('categories')}
          className={`border-b-2 px-3 py-2.5 text-sm font-semibold transition-colors ${
            tab === 'categories'
              ? 'border-accent text-accent-ink'
              : 'border-transparent text-ink-muted hover:text-ink'
          }`}
        >
          Categories
        </button>
        <button
          type="button"
          onClick={() => setTab('items')}
          className={`border-b-2 px-3 py-2.5 text-sm font-semibold transition-colors ${
            tab === 'items'
              ? 'border-accent text-accent-ink'
              : 'border-transparent text-ink-muted hover:text-ink'
          }`}
        >
          Content
        </button>
        <button
          type="button"
          onClick={() => setTab('tips')}
          className={`border-b-2 px-3 py-2.5 text-sm font-semibold transition-colors ${
            tab === 'tips'
              ? 'border-accent text-accent-ink'
              : 'border-transparent text-ink-muted hover:text-ink'
          }`}
        >
          Tips
        </button>
      </div>

      {tab === 'categories' && <CategoriesPanel />}
      {tab === 'items' && <ItemsPanel />}
      {tab === 'tips' && <TipsPanel />}
    </div>
  )
}
