import { useEffect, useRef, useState } from 'react'
import { Menu, ChevronDown, LogOut } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import RoleBadge from '../RoleBadge'

export default function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { session, roles, signOut } = useAuth()
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  const email = session?.user.email ?? 'Unknown'
  const initial = email.charAt(0).toUpperCase()

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', onClickOutside)
    return () => document.removeEventListener('mousedown', onClickOutside)
  }, [])

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border bg-surface/80 px-4 backdrop-blur md:px-6">
      <button
        type="button"
        onClick={onMenuClick}
        className="rounded-md p-2 text-ink-muted hover:bg-canvas md:hidden"
        aria-label="Open navigation"
      >
        <Menu size={20} />
      </button>

      <div className="hidden md:block" />

      <div ref={menuRef} className="relative">
        <button
          type="button"
          onClick={() => setMenuOpen((v) => !v)}
          className="flex items-center gap-2.5 rounded-lg py-1.5 pl-1.5 pr-2.5 hover:bg-canvas"
          aria-haspopup="true"
          aria-expanded={menuOpen}
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-accent text-sm font-semibold text-white">
            {initial}
          </span>
          <span className="hidden text-sm font-medium text-ink sm:block">{email}</span>
          <ChevronDown size={16} className="text-ink-faint" />
        </button>

        {menuOpen && (
          <div className="absolute right-0 top-full mt-2 w-64 rounded-xl border border-border bg-surface p-3 shadow-panel">
            <p className="truncate px-1 text-sm font-medium text-ink">{email}</p>
            <div className="mt-2 flex flex-wrap gap-1.5 px-1">
              {roles.map((role) => (
                <RoleBadge key={role} role={role} />
              ))}
            </div>
            <div className="my-3 h-px bg-border" />
            <button
              type="button"
              onClick={() => void signOut()}
              className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm font-medium text-danger hover:bg-danger-soft"
            >
              <LogOut size={16} />
              Log out
            </button>
          </div>
        )}
      </div>
    </header>
  )
}
