# Basseer Admin Dashboard — Foundation: Final Report

Task scope: authentication, authorization architecture, route protection, and
dashboard shell only. Content/Advertisement/User/Assessment management are
explicitly out of scope for this task (see spec Steps 16, 17, 21) and are not
implemented.

---

## 1–2. Files created / modified

**Modified:** none. Nothing in the existing Basseer project (frontend or
backend) was changed. The Basseer user app was not touched at all.

**Created — Supabase (project `dffbbjstorpxjrjhyhwt`, "BASSER - بصير"):**
- Migration `20260821214704_admin_roles_foundation` (applied and tracked in
  Supabase's migration history)
- Table `public.admin_roles`
- Functions `private.is_admin()`, `private.is_super_admin()`,
  `private.has_admin_role(text)`
- 4 RLS policies on `admin_roles` (select/insert/update/delete)

**Created — new repo `basseer-admin/` (separate app):** 34 files — full list
in `README.md`'s "Project structure" section. Notable ones:
- `src/lib/supabase.ts` — client using only the public anon/publishable key
- `src/contexts/AuthContext.tsx` — session + role resolution
- `src/components/ProtectedRoute.tsx` — route guard
- `src/components/layout/{Sidebar,Topbar,AdminLayout}.tsx` — shell
- `src/pages/{Login,AccessDenied,ConnectionError,NotFound}.tsx`
- `src/pages/dashboard/{Overview,Content,Advertisements,Users,Assessments,Settings}.tsx`
- `supabase/migrations/20260821214704_admin_roles_foundation.sql` — local
  copy of the applied migration, for version control

---

## 3. Database tables created

One: `public.admin_roles`.

| Column | Type | Notes |
|---|---|---|
| `id` | uuid, PK | `gen_random_uuid()` |
| `user_id` | uuid, FK → `auth.users(id)` | `on delete cascade` |
| `role` | text | `CHECK (role in ('super_admin','content_editor','support'))` |
| `created_at` | timestamptz | defaults `now()` |
| `created_by` | uuid, FK → `auth.users(id)` | nullable, `on delete set null`, audit trail |

`unique (user_id, role)` — a user can hold more than one role (e.g.
`content_editor` + `support`), but not the same role twice.

No existing table was modified. No existing table's RLS was touched.

**Why `text` + `CHECK` instead of a Postgres `enum`:** the existing project
already uses this pattern for constrained string sets (e.g. `audience` on
`content_categories`/`content_items`). Matching it means adding a role later
is a plain `ALTER TABLE ... DROP/ADD CONSTRAINT` migration instead of the
more awkward `ALTER TYPE ... ADD VALUE` enum dance — directly serving the
spec's "designed so more roles can be added later" requirement.

---

## 4. SQL migration

Applied via Supabase (approved by you) and saved at
`supabase/migrations/20260821214704_admin_roles_foundation.sql`. Full text is
in that file — summary of what it does:

1. Creates `admin_roles` with the schema above, RLS enabled.
2. Creates 3 helper functions in the project's existing `private` schema
   (not exposed via PostgREST — confirmed by checking `pg_event_trigger` /
   the security advisor before and after: no new advisor warnings appeared).
3. Creates 4 RLS policies (below).
4. `grant ... to authenticated` + `revoke all ... from anon` on `admin_roles`
   specifically, as defense-in-depth on top of RLS default-deny (stricter
   than this project's normal default table privileges, appropriate for a
   sensitive administrative table per spec Step 14).

No `DROP`, no `DELETE`, no disabling of RLS anywhere, no `USING (true)`.

---

## 5. RLS policies

All four are `to authenticated` only — no policy targets `anon` at all, so
anonymous requests are denied by default regardless of table grants.

| Policy | Operation | Rule |
|---|---|---|
| `admin_roles_select_self_or_super` | SELECT | own row, or any row if `private.is_super_admin()` |
| `admin_roles_insert_super_admin_only` | INSERT | only if `private.is_super_admin()` |
| `admin_roles_update_super_admin_only` | UPDATE | only if `private.is_super_admin()` |
| `admin_roles_delete_super_admin_only` | DELETE | only if `private.is_super_admin()` |

The helper functions are `SECURITY DEFINER`, `STABLE`, with `search_path`
explicitly pinned (`set search_path = public, private`) to avoid search-path
hijacking — and they live in the `private` schema specifically so they
**cannot be called directly over the REST API** by `anon`/`authenticated`
even though they're `SECURITY DEFINER`. This mirrors the project's own
pre-existing `private.user_owns_child()` pattern rather than inventing a new
one.

No circular RLS: the helper functions query `admin_roles` directly as
`SECURITY DEFINER` (bypassing RLS internally, same as the project's existing
pattern), so policies referencing them don't recursively re-trigger RLS
evaluation on the same table.

---

## 6. Admin roles created

Architecture only, as instructed — **zero rows** were inserted into
`admin_roles`. Nobody has admin access yet, by design: since only an existing
super_admin can write to that table, the very first grant has to happen
outside the app (SQL editor), which is documented in `README.md` under
"First super_admin." You opted to do this yourself rather than give me an
email to seed directly.

Three roles are supported now (`super_admin`, `content_editor`, `support`),
matching spec Steps 5–7. Only the authorization *architecture* for
content_editor and support was prepared — no content/support UI exists yet,
per Steps 6 and 7.

---

## 7. Authentication flow

Supabase Auth email/password only — no separate password system, no
hardcoded credentials, no `if (email === "admin@example.com")` anywhere.

```
Admin opens Admin Dashboard
        │
        ▼
AuthContext resolves supabase.auth.getSession()  →  status: 'loading'
        │
        ├─ no session          → status: 'unauthenticated' → redirect /login
        │
        └─ session exists      → query admin_roles for this user_id
                │
                ├─ 0 rows       → status: 'unauthorized'  → Access Denied (Arabic message)
                ├─ query fails  → status: 'error'          → Connection problem (retry)
                └─ ≥1 row       → status: 'authorized'     → Dashboard renders
```

`onAuthStateChange` keeps this reactive — sign-in, sign-out, and token
refresh all re-run role resolution automatically, so there's no separate
"log back in" step needed after a session refresh.

---

## 8. Route protection implementation

`ProtectedRoute` (`src/components/ProtectedRoute.tsx`) wraps the entire `/`
route tree in `App.tsx`, so every dashboard path — `/`, `/content`,
`/advertisements`, `/users`, `/assessments`, `/settings` — goes through the
same single guard:

- `loading` → spinner only, **nothing protected renders** (this is what
  prevents the flash-of-protected-content / auth race condition called out
  in Step 8)
- `unauthenticated` → `<Navigate to="/login" />` (with a "session expired"
  flag if this followed a real session, vs. a fresh unauthenticated visit)
- `error` → Connection problem screen with Retry
- `unauthorized` → Access Denied screen (blocks the Outlet entirely — the
  sidebar/dashboard never renders)
- `authorized` → renders the protected `<Outlet />`

Because this is enforced by live auth-context state on every render (not a
cached page), browser back-navigation after logout re-evaluates the guard
and redirects — it can't expose a stale protected view.

---

## 9. Supabase configuration required

Already wired into `.env` for this project:

```
VITE_SUPABASE_URL=https://dffbbjstorpxjrjhyhwt.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_kw1frEZ_kvEg7AHy8tltBg_AVQSWaji
```

Both are public-safe by design. No `service_role` key is used, stored, or
referenced anywhere in this app — see the security verification below.

---

## 10. Deployment instructions

See `README.md` → "Deployment." Short version: it's a static Vite build
(`npm run build` → `dist/`), deployable to any static host (Vercel, Netlify,
Cloudflare Pages, etc.) with `VITE_SUPABASE_URL` and
`VITE_SUPABASE_PUBLISHABLE_KEY` set as build-time env vars, plus an SPA
fallback rewrite rule so client-side routes survive a hard refresh.

---

## 11. Security verification results

| Check | Result |
|---|---|
| `service_role` string anywhere in built bundle | **Not found** (`grep -ri "service_role" dist/assets/*.js` → no matches) |
| Only the publishable key embedded in bundle | Confirmed — exactly one key, `sb_publishable_...`, matches `.env` |
| `admin_roles` RLS enabled | Confirmed via `pg_policies` query after migration |
| `anon` has no grants on `admin_roles` | Confirmed (`revoke all ... from anon` applied) |
| New security-advisor warnings introduced | **None** — advisor output identical before/after migration |
| Existing tables' RLS/policies touched | **None** — verified via `pg_policies` diff, only `admin_roles` rows added |
| `npm run build` (TypeScript + Vite) | Passes, zero errors |
| `npm audit` | 1 moderate finding remains: `esbuild`'s **dev server** (not the production build) accepting cross-origin requests. Fixing it requires jumping to Vite 8, a major version released very recently — I left this for you to weigh, since production output is unaffected and the practical exposure is local-dev-only. See note below. |

**On the remaining `npm audit` item:** two other CVEs (in `react-router`)
were resolved by upgrading to `react-router-dom` v7.18.2 during this build —
verified with a clean rebuild afterward. The one that's left concerns
`esbuild`'s dev server, not anything shipped to production; `vite build`
output doesn't run esbuild's dev server at all. I chose not to force a Vite 8
upgrade during a foundation task for stability reasons, but it's a one-line
`package.json` bump whenever you're ready.

---

## 12. Manual testing checklist

Spec's 6 test scenarios, and how to run each against the real app:

1. **Unauthenticated → `/dashboard`:** open the app in a private/incognito
   window (no session) → confirms redirect to `/login`. *(Verified in code
   review — `ProtectedRoute` returns `<Navigate to="/login" />` for
   `unauthenticated`; not yet run against a live deployed instance.)*
2. **Authenticated normal Basseer user opens Admin Dashboard:** sign in with
   any Basseer end-user account (one with no `admin_roles` row) → should show
   the Arabic Access Denied screen, not the dashboard. *(Verified visually —
   see the access-denied screenshot taken during this build. Not yet tested
   with a real non-admin Basseer account.)*
3. **Authorized `super_admin` logs in:** after you grant yourself
   `super_admin` per the README, sign in → dashboard should open. *(Not yet
   testable — no admin_roles row exists yet by design; this is the one test
   that needs your action first.)*
4. **Admin logs out:** click the profile menu → Log out → confirms session
   clears, `/login` shows, and pressing the browser back button doesn't
   expose the dashboard. *(Code-reviewed; guard re-evaluates on every render
   so this should hold — worth a manual click-through once you have a real
   admin account.)*
5. **Normal user attempts a direct database write to `admin_roles`:** from
   the browser console of a signed-in non-admin account, try
   `supabase.from('admin_roles').insert(...)` → should be rejected by RLS.
   *(Verified structurally via the policy definitions and grants; recommend
   an actual console test once you have a non-admin test account.)*
6. **Inspect production bundle for `service_role`:** done — see Security
   verification table above.

I ran the visual/behavioral checks I could without a live deployment or real
admin credentials (screenshots of all 4 auth states, responsive layout at
tablet width, a clean production build, and the bundle grep). Tests 1–5
above are code-verified but I'd treat them as "please re-run once deployed
with a real account," since I don't have a way to fully simulate a second
real Basseer end-user account or a deployed URL from here.
