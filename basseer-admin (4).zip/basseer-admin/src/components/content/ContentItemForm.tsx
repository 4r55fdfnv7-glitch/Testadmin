import { useState, type ChangeEvent, type FormEvent } from 'react'
import { Upload, Link as LinkIcon } from 'lucide-react'
import type {
  ContentItem,
  ContentItemInput,
  ContentType,
  ContentCategory,
} from '../../types/content'
import { AUDIENCE_LABELS, CONTENT_TYPE_LABELS } from '../../types/content'
import { uploadThumbnail } from '../../lib/contentApi'

interface ContentItemFormProps {
  initial?: ContentItem | null
  categories: ContentCategory[]
  defaultCategoryId?: string
  nextSortOrder: number
  onSubmit: (values: ContentItemInput) => Promise<void>
  onCancel: () => void
}

// 'tip' is deliberately excluded here — tips have their own dedicated
// editor (full_content + preview) in the Tips tab, so they shouldn't be
// creatable through this generic form without those fields.
const CONTENT_TYPES = (Object.keys(CONTENT_TYPE_LABELS) as ContentType[]).filter((t) => t !== 'tip')

export default function ContentItemForm({
  initial,
  categories,
  defaultCategoryId,
  nextSortOrder,
  onSubmit,
  onCancel,
}: ContentItemFormProps) {
  const [categoryId, setCategoryId] = useState(
    initial?.category_id ?? defaultCategoryId ?? categories[0]?.id ?? '',
  )
  const [title, setTitle] = useState(initial?.title ?? '')
  const [description, setDescription] = useState(initial?.description ?? '')
  const [contentType, setContentType] = useState<ContentType>(initial?.content_type ?? 'article')
  const [contentUrl, setContentUrl] = useState(initial?.content_url ?? '')
  const [thumbnailUrl, setThumbnailUrl] = useState(initial?.thumbnail_url ?? '')
  const [sortOrder, setSortOrder] = useState(initial?.sort_order ?? nextSortOrder)
  const [isPublished, setIsPublished] = useState(initial?.is_published ?? false)
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const selectedCategory = categories.find((c) => c.id === categoryId)

  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError(null)
    try {
      const url = await uploadThumbnail(file)
      setThumbnailUrl(url)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed. Please try again.')
    } finally {
      setUploading(false)
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!title.trim()) {
      setError('Title is required.')
      return
    }
    if (!categoryId) {
      setError('Choose a category.')
      return
    }
    setSubmitting(true)
    setError(null)
    try {
      await onSubmit({
        category_id: categoryId,
        title: title.trim(),
        description: description.trim() || null,
        full_content: initial?.full_content ?? null,
        content_type: contentType,
        content_url: contentUrl.trim() || null,
        thumbnail_url: thumbnailUrl.trim() || null,
        sort_order: sortOrder,
        is_published: isPublished,
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
      setSubmitting(false)
    }
  }

  if (categories.length === 0) {
    return (
      <div className="text-sm text-ink-muted">
        Add a category first — content items need one to belong to.
        <div className="mt-4 flex justify-end">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg border border-border px-4 py-2 text-sm font-semibold text-ink hover:bg-canvas"
          >
            Close
          </button>
        </div>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="mb-1.5 block text-sm font-medium text-ink">Title</label>
        <input
          dir="auto"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          autoFocus
          className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
        />
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ink">Description (optional)</label>
        <textarea
          dir="auto"
          value={description ?? ''}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Category</label>
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {AUDIENCE_LABELS[c.audience]}
              </option>
            ))}
          </select>
          {selectedCategory && (
            <p className="mt-1 text-xs text-ink-faint">
              Audience follows the category:{' '}
              <strong className="text-ink-muted">{AUDIENCE_LABELS[selectedCategory.audience]}</strong>
            </p>
          )}
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Type</label>
          <select
            value={contentType}
            onChange={(e) => setContentType(e.target.value as ContentType)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          >
            {CONTENT_TYPES.map((t) => (
              <option key={t} value={t}>
                {CONTENT_TYPE_LABELS[t]}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ink">Content URL (optional)</label>
        <input
          value={contentUrl ?? ''}
          onChange={(e) => setContentUrl(e.target.value)}
          placeholder="https://…  (e.g. a video link or article link)"
          className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
        />
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ink">Thumbnail</label>
        <div className="flex items-center gap-3">
          {thumbnailUrl ? (
            <img
              src={thumbnailUrl}
              alt=""
              className="h-14 w-14 shrink-0 rounded-lg border border-border object-cover"
            />
          ) : (
            <div className="h-14 w-14 shrink-0 rounded-lg border border-dashed border-border bg-canvas" />
          )}
          <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-ink hover:bg-canvas">
            <Upload size={14} />
            {uploading ? 'Uploading…' : 'Upload image'}
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleFileChange}
              disabled={uploading}
            />
          </label>
        </div>
        <div className="mt-2 flex items-center gap-1.5">
          <LinkIcon size={13} className="shrink-0 text-ink-faint" />
          <input
            value={thumbnailUrl ?? ''}
            onChange={(e) => setThumbnailUrl(e.target.value)}
            placeholder="or paste an image URL"
            className="w-full rounded-lg border border-border px-3 py-2 text-xs text-ink-muted focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Sort order</label>
          <input
            type="number"
            value={sortOrder}
            onChange={(e) => setSortOrder(Number(e.target.value))}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
        <div className="flex items-end pb-2.5">
          <label className="flex items-center gap-2 text-sm font-medium text-ink">
            <input
              type="checkbox"
              checked={isPublished}
              onChange={(e) => setIsPublished(e.target.checked)}
              className="h-4 w-4 rounded border-border text-accent focus:ring-accent"
            />
            Published (visible in the Basseer app)
          </label>
        </div>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}

      <div className="flex justify-end gap-2 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-border px-4 py-2 text-sm font-semibold text-ink hover:bg-canvas"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={submitting || uploading}
          className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white hover:bg-accent-ink disabled:opacity-60"
        >
          {submitting ? 'Saving…' : initial ? 'Save changes' : 'Add content'}
        </button>
      </div>
    </form>
  )
}
