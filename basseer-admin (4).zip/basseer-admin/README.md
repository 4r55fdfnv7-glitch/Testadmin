# Basseer Admin Dashboard — Foundation

A **separate application** from the Basseer user app. It shares the same Supabase
project (database, auth, storage) but the two apps never talk to each other directly.

This is the foundation only: authentication, role-based authorization, route
protection, and the dashboard shell. Content, Advertisement, User, and
Assessment management are deliberately not implemented yet — see
`FINAL_REPORT.md` for the full scope and reasoning.

## Requirements

- Node.js 18+
- The Supabase project's URL and **publishable/anon key** (never the service_role key)

## Setup

```bash
npm install
cp .env.example .env   # if .env isn't already present — it's pre-filled for this project
npm run dev
```

The app runs at `http://localhost:5174` (deliberately a different port from a
typical user-app dev server, so both can run side by side).

`.env` is already populated with this project's real URL and publishable key —
both are safe to expose in a browser bundle by design; the anon key alone
grants no access beyond what RLS allows.

## First super_admin

`admin_roles` starts empty on purpose: nobody can grant themselves admin
access through the app itself (that's the point of the RLS policies — only an
existing super_admin can write to that table, so someone has to be first
outside the app). Grant yourself access via the Supabase SQL editor:

```sql
insert into public.admin_roles (user_id, role)
values (
  (select id from auth.users where email = 'you@example.com'),
  'super_admin'
);
```

The user must already exist in `auth.users` (sign up once through Supabase
Auth — e.g. via the Supabase dashboard's "Add user" screen — before running
this).

## Adding more admins

Once you have a super_admin, sign in and use the SQL editor (or, once the
Users module ships, the UI) the same way — `insert into admin_roles ...` for
each person, with `role` one of `super_admin`, `content_editor`, `support`.

## Adding a new role later

Roles are enforced by a `CHECK` constraint, not an enum, specifically so this
is a plain migration:

```sql
alter table public.admin_roles drop constraint admin_roles_role_check;
alter table public.admin_roles add constraint admin_roles_role_check
  check (role in ('super_admin', 'content_editor', 'support', 'your_new_role'));
```

Then gate any new feature with `private.has_admin_role('your_new_role')` in a
policy, or `roles.includes('your_new_role')` on the frontend (see
`src/contexts/AuthContext.tsx`).

## Deployment

This is a static Vite build — deploy it anywhere that serves static files
(Vercel, Netlify, Cloudflare Pages, S3+CloudFront, etc.):

```bash
npm run build   # outputs to dist/
```

Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` as environment
variables in your hosting provider — same values as `.env`. Do **not** set a
`service_role` key as an environment variable anywhere this app is hosted;
this app has no server-side component, so there is nowhere for it to live
safely. If a future module needs privileged operations (e.g. deleting a
user's auth account), implement it as a Supabase Edge Function — the project
already has one precedent (`delete-account`).

Because this is a client-side SPA, configure your host to redirect all
unmatched paths to `/index.html` (a "SPA fallback" / "rewrite rule") so
routes like `/content` work on a hard refresh, not just client-side
navigation. Vercel and Netlify do this automatically for Vite projects;
other hosts may need an explicit rewrite rule.

## Project structure

```
src/
  lib/supabase.ts              Supabase client (publishable key only)
  types/admin.ts                AdminRoleName, AuthStatus types
  contexts/AuthContext.tsx      Resolves session -> admin_roles in one place
  components/
    ProtectedRoute.tsx          The one route guard every admin route uses
    layout/                     Sidebar, Topbar, AdminLayout (the shell)
    ComingSoon.tsx               Shared placeholder for unbuilt modules
    StatCard.tsx, RoleBadge.tsx, Logo.tsx
  pages/
    Login.tsx, AccessDenied.tsx, ConnectionError.tsx, NotFound.tsx
    dashboard/                  Overview (real) + 5 placeholder modules
supabase/
  migrations/                   SQL applied to the shared Supabase project
```

## What's real vs. placeholder right now

- **Real**: login, logout, session handling, role resolution, route
  protection, the dashboard shell, and the Overview page's foundation-status
  summary.
- **Placeholder** ("coming soon", no fake data): Content, Advertisements,
  Users, Assessments, Settings. The Overview page's stat cards show `--`
  rather than invented numbers, because the admin-read RLS policies those
  counts would need don't exist yet — that's intentionally deferred to the
  modules that need them.
