-- =========================================================
-- Basseer Admin Dashboard — Task 2: Content Management
-- Applied to project dffbbjstorpxjrjhyhwt via Supabase migration
-- 20260828222414_content_management_foundation.
--
-- Purely additive. Does not touch admin_roles, auth, or any existing
-- SELECT policy that the Basseer user app already relies on.
-- =========================================================

-- 1. Shared authorization helper, same pattern as private.is_super_admin().
--    True for super_admin OR content_editor. Used by every new policy below,
--    so content-write authorization has exactly one definition.
create or replace function private.can_manage_content()
returns boolean
language sql
security definer
stable
set search_path = public, private
as $$
  select exists (
    select 1 from public.admin_roles
    where user_id = auth.uid()
      and role in ('super_admin', 'content_editor')
  );
$$;

comment on function private.can_manage_content() is 'True if the current user is a super_admin or content_editor. Single source of truth for content_categories/content_items/content-thumbnails write access.';

-- 2. content_categories: additive policies only. The existing
--    content_categories_select_active policy (anon/authenticated, is_active=true)
--    is untouched, so the user app's existing query is unaffected.
create policy content_categories_select_admin
  on public.content_categories for select
  to authenticated
  using (private.can_manage_content());

create policy content_categories_insert_admin
  on public.content_categories for insert
  to authenticated
  with check (private.can_manage_content());

create policy content_categories_update_admin
  on public.content_categories for update
  to authenticated
  using (private.can_manage_content())
  with check (private.can_manage_content());

-- Delete is allowed only when the category is actually safe to remove:
-- authorized AND no content_items still reference it (category_id is
-- ON DELETE CASCADE, so this stops an admin from silently mass-deleting
-- content by deleting its category). Deactivating (is_active=false) via
-- the update policy above remains available regardless — that's "archive".
create policy content_categories_delete_admin_if_empty
  on public.content_categories for delete
  to authenticated
  using (
    private.can_manage_content()
    and not exists (
      select 1 from public.content_items
      where content_items.category_id = content_categories.id
    )
  );

-- 3. content_items: additive policies only. The existing
--    content_items_select_published policy (anon/authenticated, is_published=true)
--    is untouched.
create policy content_items_select_admin
  on public.content_items for select
  to authenticated
  using (private.can_manage_content());

create policy content_items_insert_admin
  on public.content_items for insert
  to authenticated
  with check (private.can_manage_content());

create policy content_items_update_admin
  on public.content_items for update
  to authenticated
  using (private.can_manage_content())
  with check (private.can_manage_content());

create policy content_items_delete_admin
  on public.content_items for delete
  to authenticated
  using (private.can_manage_content());

-- 4. New storage bucket for content-library thumbnails only. Public, images only,
--    small size limit. Does not touch or duplicate videos/avatars/profile/advertisements.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'content-thumbnails',
  'content-thumbnails',
  true,
  5242880, -- 5MB
  array['image/jpeg', 'image/png', 'image/webp']
)
on conflict (id) do nothing;

-- Public read (matches the existing advertisements_storage_select convention
-- for this project's other public bucket).
create policy content_thumbnails_storage_select
  on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'content-thumbnails');

create policy content_thumbnails_storage_insert_admin
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'content-thumbnails' and private.can_manage_content());

create policy content_thumbnails_storage_update_admin
  on storage.objects for update
  to authenticated
  using (bucket_id = 'content-thumbnails' and private.can_manage_content())
  with check (bucket_id = 'content-thumbnails' and private.can_manage_content());

create policy content_thumbnails_storage_delete_admin
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'content-thumbnails' and private.can_manage_content());
