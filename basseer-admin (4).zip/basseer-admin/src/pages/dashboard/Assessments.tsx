import { ClipboardList } from 'lucide-react'
import ComingSoon from '../../components/ComingSoon'

export default function Assessments() {
  return (
    <ComingSoon
      icon={ClipboardList}
      title="Assessment oversight will be available here"
      description="Reviewing assessment activity is a separate task, and will be scoped carefully around child data sensitivity."
    />
  )
}
