/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        canvas: '#F4F6F9',
        surface: '#FFFFFF',
        ink: {
          DEFAULT: '#101828',
          muted: '#667085',
          faint: '#98A2B3',
        },
        border: '#E4E7EC',
        accent: {
          DEFAULT: '#2954E5',
          soft: '#EEF2FF',
          ink: '#1A3BB8',
        },
        danger: {
          DEFAULT: '#D92D20',
          soft: '#FEF3F2',
        },
        success: {
          DEFAULT: '#12B76A',
          soft: '#ECFDF3',
        },
        warning: {
          DEFAULT: '#F79009',
          soft: '#FFFAEB',
        },
      },
      fontFamily: {
        sans: [
          'Inter',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'system-ui',
          'sans-serif',
        ],
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(16, 24, 40, 0.05)',
        panel: '0 4px 12px -2px rgba(16, 24, 40, 0.08), 0 2px 4px -2px rgba(16, 24, 40, 0.04)',
      },
      borderRadius: {
        xl: '0.875rem',
      },
    },
  },
  plugins: [],
}
