import { useState } from 'react'
import { ShieldAlert } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import HospitalsPanel from './hospitals/HospitalsPanel'
import CitiesPanel from './hospitals/CitiesPanel'
import ReferralsPanel from './hospitals/ReferralsPanel'

type Tab = 'hospitals' | 'cities' | 'referrals'

export default function Hospitals() {
  const { isSuperAdmin } = useAuth()
  const [tab, setTab] = useState<Tab>('hospitals')

  if (!isSuperAdmin) {
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center rounded-xl border border-dashed border-border bg-surface px-6 py-16 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning-soft text-warning">
          <ShieldAlert size={22} />
        </div>
        <h2 className="mt-4 text-lg font-bold text-ink">Super admin access required</h2>
        <p className="mt-1.5 max-w-sm text-sm text-ink-muted">
          Hospital management (including commercial commission terms) is restricted to super
          admins. Ask a super admin if you need access.
        </p>
      </div>
    )
  }

  const TABS: { key: Tab; label: string }[] = [
    { key: 'hospitals', label: 'Hospitals' },
    { key: 'cities', label: 'Cities' },
    { key: 'referrals', label: 'Referrals' },
  ]

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6">
        <h1 className="text-xl font-bold tracking-tight text-ink">Hospital Directory</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Changes here appear in the Basseer app automatically — activating a hospital makes it
          visible right away, no app update needed.
        </p>
      </div>

      <div className="mb-6 flex gap-1 border-b border-border">
        {TABS.map(({ key, label }) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`border-b-2 px-3 py-2.5 text-sm font-semibold transition-colors ${
              tab === key ? 'border-accent text-accent-ink' : 'border-transparent text-ink-muted hover:text-ink'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'hospitals' && <HospitalsPanel />}
      {tab === 'cities' && <CitiesPanel />}
      {tab === 'referrals' && <ReferralsPanel />}
    </div>
  )
}
