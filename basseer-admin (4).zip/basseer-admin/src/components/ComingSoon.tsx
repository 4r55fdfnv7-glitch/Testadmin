import type { LucideIcon } from 'lucide-react'
import { LogoMark } from './Logo'

interface ComingSoonProps {
  icon: LucideIcon
  title: string
  description: string
}

export default function ComingSoon({ icon: Icon, title, description }: ComingSoonProps) {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center rounded-xl border border-dashed border-border bg-surface px-6 py-16 text-center">
      <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-accent-soft text-accent">
        <Icon size={24} />
      </div>
      <h2 className="mt-5 text-lg font-bold text-ink">{title}</h2>
      <p className="mt-1.5 max-w-sm text-sm text-ink-muted">{description}</p>
      <div className="mt-6 flex items-center gap-1.5 text-xs font-medium text-ink-faint">
        <LogoMark size={14} />
        Coming in a later task
      </div>
    </div>
  )
}
