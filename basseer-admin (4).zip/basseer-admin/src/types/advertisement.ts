// Mirrors public.advertisements exactly.
export interface Advertisement {
  id: string
  image_url: string
  destination_url: string | null
  title: string | null
  start_at: string // timestamptz ISO string
  end_at: string // timestamptz ISO string
  is_active: boolean
  sort_order: number
  created_at: string
  updated_at: string
}

export interface AdvertisementInput {
  image_url: string
  destination_url: string | null
  title: string | null
  start_at: string
  end_at: string
  is_active: boolean
  sort_order: number
}

// Derived, display-only status — is_active alone doesn't tell you whether an
// ad is actually showing right now (it might be scheduled or expired).
export type AdComputedStatus = 'live' | 'scheduled' | 'expired' | 'inactive'

export function computeAdStatus(ad: Pick<Advertisement, 'is_active' | 'start_at' | 'end_at'>): AdComputedStatus {
  if (!ad.is_active) return 'inactive'
  const now = Date.now()
  const start = new Date(ad.start_at).getTime()
  const end = new Date(ad.end_at).getTime()
  if (now < start) return 'scheduled'
  if (now > end) return 'expired'
  return 'live'
}
