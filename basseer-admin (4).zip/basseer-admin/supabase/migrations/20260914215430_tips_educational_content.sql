-- =========================================================
-- Basseer Admin Dashboard — Tips / Educational Content
-- Deliberately NOT a new content system: tips are content_items with
-- content_type = 'tip', reusing the exact same categories, RLS policies,
-- and content-thumbnails bucket already built for the Content Library.
-- No RLS changes at all — the existing policies don't reference
-- content_type, so they already cover 'tip' rows automatically.
-- =========================================================

-- 1. The one genuinely missing field: tips need a long-form body distinct
--    from the existing short `description` field.
alter table public.content_items add column full_content text;

comment on column public.content_items.full_content is 'Long-form body text. Used by tips/educational content (content_type = ''tip''); optional for other content types.';

-- 2. Allow 'tip' as a content_type, alongside the existing video/article/
--    activity/resource values. Nothing existing is removed.
alter table public.content_items drop constraint content_items_type_check;
alter table public.content_items add constraint content_items_type_check
  check (content_type = any (array['video','article','activity','resource','tip']));

-- 3. Allow 'both' as an audience value, on both tables, alongside the
--    existing parent/child values — needed so a tip's category (and thus
--    the tip itself, since content_items.audience is derived from its
--    category by the existing basseer_content_items_sync_audience trigger)
--    can target both audiences at once.
alter table public.content_categories drop constraint content_categories_audience_check;
alter table public.content_categories add constraint content_categories_audience_check
  check (audience = any (array['parent','child','both']));

alter table public.content_items drop constraint content_items_audience_check;
alter table public.content_items add constraint content_items_audience_check
  check (audience = any (array['parent','child','both']));
