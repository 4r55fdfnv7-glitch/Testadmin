import { useEffect, useRef, type ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import AccessDenied from '../pages/AccessDenied'
import ConnectionError from '../pages/ConnectionError'

/**
 * Wraps every admin route. Deliberately renders NOTHING protected until
 * status has resolved past 'loading' — this is what stops protected
 * content from flashing before authorization is known (Step 8).
 */
export default function ProtectedRoute({ children }: { children: ReactNode }) {
  const { status, session } = useAuth()

  // Distinguishes "your session expired" from "you were never signed in",
  // purely for the login page's messaging — doesn't affect the redirect itself.
  const everHadSession = useRef(false)
  useEffect(() => {
    if (session) everHadSession.current = true
  }, [session])

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas">
        <div className="flex flex-col items-center gap-3">
          <div
            className="h-8 w-8 animate-spin rounded-full border-2 border-accent-soft border-t-accent"
            role="status"
            aria-label="Checking your access"
          />
          <p className="text-sm text-ink-muted">Checking your access…</p>
        </div>
      </div>
    )
  }

  if (status === 'unauthenticated') {
    return <Navigate to={everHadSession.current ? '/login?reason=expired' : '/login'} replace />
  }

  if (status === 'error') {
    return <ConnectionError />
  }

  if (status === 'unauthorized') {
    return <AccessDenied />
  }

  return <>{children}</>
}
