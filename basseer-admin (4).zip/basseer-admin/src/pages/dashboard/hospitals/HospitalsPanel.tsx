import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, ChevronUp, ChevronDown, Eye, EyeOff, ExternalLink } from 'lucide-react'
import type { Hospital, City } from '../../../types/hospital'
import * as api from '../../../lib/hospitalApi'
import Modal from '../../../components/Modal'
import ConfirmDialog from '../../../components/ConfirmDialog'
import HospitalForm from '../../../components/hospitals/HospitalForm'

export default function HospitalsPanel() {
  const [hospitals, setHospitals] = useState<Hospital[]>([])
  const [cities, setCities] = useState<City[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const [formState, setFormState] = useState<{ mode: 'add' } | { mode: 'edit'; hospital: Hospital } | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Hospital | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      const [h, c] = await Promise.all([api.listHospitals(), api.listCities()])
      setHospitals(h)
      setCities(c)
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load hospitals.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  async function handleToggleActive(hospital: Hospital) {
    setBusyId(hospital.id)
    try {
      await api.updateHospital(hospital.id, { is_active: !hospital.is_active })
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not update hospital.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleMove(index: number, direction: -1 | 1) {
    const other = hospitals[index + direction]
    if (!other) return
    const current = hospitals[index]
    setBusyId(current.id)
    try {
      await api.swapHospitalOrder(current, other)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not reorder hospitals.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    setDeleteError(null)
    try {
      await api.deleteHospital(deleteTarget.id)
      setDeleteTarget(null)
      await load()
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Could not delete hospital.')
    } finally {
      setDeleting(false)
    }
  }

  async function handleFormSubmit(values: Parameters<typeof api.createHospital>[0]) {
    if (formState?.mode === 'edit') {
      await api.updateHospital(formState.hospital.id, values)
    } else {
      await api.createHospital(values)
    }
    setFormState(null)
    await load()
  }

  if (loading) {
    return <p className="text-sm text-ink-muted">Loading hospitals…</p>
  }

  return (
    <div>
      {loadError && (
        <div className="mb-4 rounded-lg border border-danger/20 bg-danger-soft px-4 py-3 text-sm text-danger">
          {loadError}
        </div>
      )}

      <div className="mb-3 flex justify-end">
        <button
          type="button"
          onClick={() => setFormState({ mode: 'add' })}
          disabled={cities.length === 0}
          className="flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-sm font-semibold text-white hover:bg-accent-ink disabled:opacity-50"
        >
          <Plus size={15} />
          Add hospital
        </button>
      </div>

      {cities.length === 0 && (
        <p className="mb-4 rounded-lg border border-warning/30 bg-warning-soft px-3.5 py-3 text-sm text-warning">
          Add a city in the Cities tab before adding hospitals.
        </p>
      )}

      {hospitals.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-10 text-center text-sm text-ink-faint">
          No hospitals yet.
        </p>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-surface">
          <table className="w-full text-sm">
            <tbody>
              {hospitals.map((hospital, index) => {
                const isBusy = busyId === hospital.id
                return (
                  <tr key={hospital.id} className={`border-b border-border last:border-0 ${isBusy ? 'opacity-50' : ''}`}>
                    <td className="w-16 px-3 py-3">
                      <div className="flex flex-col items-center gap-0.5">
                        <button
                          type="button"
                          disabled={index === 0 || isBusy}
                          onClick={() => handleMove(index, -1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move up"
                        >
                          <ChevronUp size={16} />
                        </button>
                        <button
                          type="button"
                          disabled={index === hospitals.length - 1 || isBusy}
                          onClick={() => handleMove(index, 1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move down"
                        >
                          <ChevronDown size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="px-2 py-3">
                      {hospital.image_url ? (
                        <img src={hospital.image_url} alt="" className="h-10 w-10 rounded-md border border-border object-cover" />
                      ) : (
                        <div className="h-10 w-10 rounded-md border border-dashed border-border bg-canvas" />
                      )}
                    </td>
                    <td className="px-2 py-3">
                      <p dir="auto" className="font-medium text-ink">
                        {hospital.name}
                      </p>
                      <p dir="auto" className="mt-0.5 text-xs text-ink-faint">
                        {hospital.city_name} · {hospital.referral_count ?? 0} referral
                        {(hospital.referral_count ?? 0) === 1 ? '' : 's'}
                      </p>
                      {hospital.booking_url && (
                        <a
                          href={hospital.booking_url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="mt-0.5 flex items-center gap-1 text-xs text-accent hover:underline"
                        >
                          <ExternalLink size={11} />
                          Booking link
                        </a>
                      )}
                    </td>
                    <td className="px-2 py-3">
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                          hospital.is_active ? 'bg-success-soft text-success' : 'bg-canvas text-ink-faint'
                        }`}
                      >
                        {hospital.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-2 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleToggleActive(hospital)}
                          title={hospital.is_active ? 'Deactivate' : 'Activate'}
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          {hospital.is_active ? <EyeOff size={15} /> : <Eye size={15} />}
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => setFormState({ mode: 'edit', hospital })}
                          title="Edit"
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => {
                            setDeleteError(null)
                            setDeleteTarget(hospital)
                          }}
                          title={
                            (hospital.referral_count ?? 0) > 0
                              ? `Has ${hospital.referral_count} referral(s) — deactivate instead`
                              : 'Delete'
                          }
                          className="rounded-md p-1.5 text-ink-muted hover:bg-danger-soft hover:text-danger"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {formState && (
        <Modal
          title={formState.mode === 'edit' ? 'Edit hospital' : 'Add hospital'}
          onClose={() => setFormState(null)}
        >
          <HospitalForm
            initial={formState.mode === 'edit' ? formState.hospital : null}
            cities={cities}
            nextSortOrder={1 + Math.max(0, ...hospitals.map((h) => h.sort_order))}
            onSubmit={handleFormSubmit}
            onCancel={() => setFormState(null)}
          />
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete hospital?"
          message={
            (deleteTarget.referral_count ?? 0) > 0
              ? `"${deleteTarget.name}" has ${deleteTarget.referral_count} referral record(s). Deleting is blocked while that's true, to preserve that history — deactivate it instead.`
              : `This permanently deletes "${deleteTarget.name}". This can't be undone.`
          }
          confirmLabel="Delete"
          danger
          busy={deleting}
          errorMessage={deleteError}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  )
}
