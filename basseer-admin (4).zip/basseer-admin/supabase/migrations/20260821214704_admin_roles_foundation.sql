-- =========================================================
-- Basseer Admin Dashboard — Foundation: admin role architecture
-- Applied to project dffbbjstorpxjrjhyhwt via Supabase migration
-- 20260821214704_admin_roles_foundation.
--
-- Purely additive. Does not touch children/assessments/content_*/advertisements,
-- and does not modify any existing RLS policy.
-- =========================================================

-- 1. admin_roles: who is an admin, and what role they hold.
create table if not exists public.admin_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('super_admin', 'content_editor', 'support')),
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null,
  unique (user_id, role)
);

comment on table public.admin_roles is
  'Basseer Admin Dashboard authorization. A row grants user_id admin access; role determines scope (super_admin, content_editor, support). Row-managed exclusively by super_admins via RLS. Independent of end-user data model (children/assessments/etc). To add a role later: ALTER TABLE public.admin_roles DROP CONSTRAINT admin_roles_role_check, ADD CONSTRAINT admin_roles_role_check CHECK (role IN (...)).';

alter table public.admin_roles enable row level security;

-- 2. Secure, non-recursive role-check helpers.
--    Live in the `private` schema (already used by this project, e.g. private.user_owns_child)
--    which is NOT exposed via PostgREST, so these cannot be called directly by anon/authenticated
--    over the API even though they are SECURITY DEFINER. They are called from inside RLS
--    policies and, later, from other functions.
create or replace function private.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public, private
as $$
  select exists (
    select 1 from public.admin_roles where user_id = auth.uid()
  );
$$;

create or replace function private.is_super_admin()
returns boolean
language sql
security definer
stable
set search_path = public, private
as $$
  select exists (
    select 1 from public.admin_roles where user_id = auth.uid() and role = 'super_admin'
  );
$$;

create or replace function private.has_admin_role(p_role text)
returns boolean
language sql
security definer
stable
set search_path = public, private
as $$
  select exists (
    select 1 from public.admin_roles where user_id = auth.uid() and role = p_role
  );
$$;

comment on function private.is_admin() is 'True if the current auth.uid() holds any admin_roles row. Used to gate dashboard entry.';
comment on function private.is_super_admin() is 'True if the current auth.uid() holds the super_admin role. Used to gate admin_roles writes and, later, sensitive modules.';
comment on function private.has_admin_role(text) is 'True if the current auth.uid() holds the given admin role. General-purpose gate for future per-role module access (e.g. content_editor).';

-- 3. RLS policies on admin_roles itself.
--    Any admin can read their OWN row (so the dashboard can resolve "what am I").
--    Only super_admins can read the full roster, or insert/update/delete any row.
--    No policy is defined for anon at all -> default-deny under RLS.
create policy admin_roles_select_self_or_super
  on public.admin_roles for select
  to authenticated
  using (user_id = auth.uid() or private.is_super_admin());

create policy admin_roles_insert_super_admin_only
  on public.admin_roles for insert
  to authenticated
  with check (private.is_super_admin());

create policy admin_roles_update_super_admin_only
  on public.admin_roles for update
  to authenticated
  using (private.is_super_admin())
  with check (private.is_super_admin());

create policy admin_roles_delete_super_admin_only
  on public.admin_roles for delete
  to authenticated
  using (private.is_super_admin());

-- 4. Explicit grants. admin_roles is a sensitive administrative table (Step 14), so unlike
--    this project's default table privileges, anon gets nothing at the grant level too
--    (defense in depth on top of RLS default-deny).
grant select, insert, update, delete on public.admin_roles to authenticated;
revoke all on public.admin_roles from anon;
