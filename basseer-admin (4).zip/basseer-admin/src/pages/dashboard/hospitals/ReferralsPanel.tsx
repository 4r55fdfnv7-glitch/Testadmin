import { useEffect, useState, useCallback } from 'react'
import { RefreshCw } from 'lucide-react'
import type { ReferralSummaryRow } from '../../../types/hospital'
import * as api from '../../../lib/hospitalApi'

export default function ReferralsPanel() {
  const [rows, setRows] = useState<ReferralSummaryRow[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      setRows(await api.listReferralSummary())
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load referral data.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  return (
    <div>
      <div className="mb-4 flex items-start justify-between gap-4 rounded-lg border border-border bg-canvas px-4 py-3">
        <p className="text-xs text-ink-muted">
          "Booking started" only means the admin's booking link was clicked and, where available,
          a booking flow was opened — it does <span className="font-semibold">not</span> mean a
          booking was completed or confirmed. This dashboard has no way to know that unless a
          hospital provides a confirmation mechanism.
        </p>
        <button
          type="button"
          onClick={() => void load()}
          className="flex shrink-0 items-center gap-1.5 rounded-lg border border-border bg-surface px-2.5 py-1.5 text-xs font-semibold text-ink hover:bg-canvas"
        >
          <RefreshCw size={13} />
          Refresh
        </button>
      </div>

      {loadError && (
        <div className="mb-4 rounded-lg border border-danger/20 bg-danger-soft px-4 py-3 text-sm text-danger">
          {loadError}
        </div>
      )}

      {loading ? (
        <p className="text-sm text-ink-muted">Loading referral activity…</p>
      ) : rows.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-10 text-center text-sm text-ink-faint">
          No referral activity recorded yet.
        </p>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-surface">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-canvas text-left text-xs font-semibold uppercase tracking-wide text-ink-faint">
                <th className="px-3 py-2.5">Hospital</th>
                <th className="px-3 py-2.5">Date</th>
                <th className="px-3 py-2.5">Clicks</th>
                <th className="px-3 py-2.5">Booking started</th>
                <th className="px-3 py-2.5">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={`${row.hospital_id}|${row.date}`} className="border-b border-border last:border-0">
                  <td dir="auto" className="px-3 py-3 font-medium text-ink">
                    {row.hospital_name}
                  </td>
                  <td className="px-3 py-3 text-ink-muted">{row.date}</td>
                  <td className="px-3 py-3 tabular-nums text-ink">{row.click_count}</td>
                  <td className="px-3 py-3 tabular-nums text-ink">{row.booking_started_count}</td>
                  <td className="px-3 py-3">
                    <span
                      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                        row.booking_started_count > 0
                          ? 'bg-accent-soft text-accent-ink'
                          : 'bg-canvas text-ink-faint'
                      }`}
                    >
                      {row.booking_started_count > 0 ? 'Booking started' : 'Clicked only'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
