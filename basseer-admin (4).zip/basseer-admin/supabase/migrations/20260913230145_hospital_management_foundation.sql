-- =========================================================
-- Basseer Admin Dashboard — Hospital Management
-- Purely additive on top of the EXISTING public.hospitals and
-- public.hospital_referrals tables (both already live, RLS-enabled,
-- explicitly commented as "managed by a future Admin Dashboard").
-- Does not touch existing content/advertisement/admin_roles objects.
-- =========================================================

-- 1. Cities — hospitals will properly reference this instead of free text.
create table public.cities (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table public.cities is 'City list for the hospitals directory (Basseer). Regular users have read-only access to active rows via RLS; the Basseer app loads this dynamically instead of hardcoding cities.';

alter table public.cities enable row level security;

create trigger cities_set_updated_at
  before update on public.cities
  for each row execute function basseer_set_updated_at();

create policy cities_select_active
  on public.cities for select
  to anon, authenticated
  using (is_active = true);

-- 2. Authorization helper — hospitals/cities/commission are a super_admin
--    capability (same scoping decision already made for advertisements).
create or replace function private.can_manage_hospitals()
returns boolean
language sql
security definer
stable
set search_path = public, private
as $$
  select private.is_super_admin();
$$;

comment on function private.can_manage_hospitals() is 'True if the current user may manage hospitals, cities, and commission agreements. Currently super_admin only.';

create policy cities_select_admin
  on public.cities for select
  to authenticated
  using (private.can_manage_hospitals());

create policy cities_insert_admin
  on public.cities for insert
  to authenticated
  with check (private.can_manage_hospitals());

create policy cities_update_admin
  on public.cities for update
  to authenticated
  using (private.can_manage_hospitals())
  with check (private.can_manage_hospitals());

create policy cities_delete_admin
  on public.cities for delete
  to authenticated
  using (private.can_manage_hospitals());
  -- Deleting a city that still has hospitals pointing to it is blocked
  -- automatically by the hospitals.city_id foreign key below (ON DELETE
  -- RESTRICT) — no extra check needed here.

-- 3. hospitals.city_id — proper reference, replacing free-text city entry
--    going forward. The existing `city` text column is kept (NOT dropped)
--    for backward compatibility with anything already reading it as text,
--    and is now kept automatically in sync by a trigger instead of being
--    hand-typed. hospitals has 0 rows today, so this is a safe, lossless
--    change either way.
alter table public.hospitals
  add column city_id uuid references public.cities(id) on delete restrict;

create or replace function public.basseer_hospitals_sync_city_text()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  select name into new.city
  from public.cities
  where id = new.city_id;

  if new.city is null then
    raise exception
      'hospitals.city_id % does not reference an existing cities row',
      new.city_id;
  end if;

  return new;
end;
$$;

comment on function public.basseer_hospitals_sync_city_text() is 'Keeps the legacy hospitals.city text column in sync with city_id, mirroring the existing basseer_content_items_sync_audience pattern. hospitals.city_id is now the source of truth; the admin dashboard only ever sets city_id.';

create trigger hospitals_sync_city_text
  before insert or update of city_id on public.hospitals
  for each row execute function public.basseer_hospitals_sync_city_text();

alter table public.hospitals
  add constraint hospitals_city_id_required check (city_id is not null) not valid;
alter table public.hospitals validate constraint hospitals_city_id_required;

-- 4. hospitals: admin visibility (all rows, not just active) + writes.
--    The existing hospitals_select_active policy (anon+authenticated,
--    active rows only) is completely untouched.
create policy hospitals_select_admin
  on public.hospitals for select
  to authenticated
  using (private.can_manage_hospitals());

create policy hospitals_insert_admin
  on public.hospitals for insert
  to authenticated
  with check (private.can_manage_hospitals());

create policy hospitals_update_admin
  on public.hospitals for update
  to authenticated
  using (private.can_manage_hospitals())
  with check (private.can_manage_hospitals());

-- Delete is blocked while referral history exists for this hospital,
-- mirroring the existing content_categories "delete only if empty" pattern
-- — pushes the admin toward deactivating instead of losing referral/
-- commission-relevant history.
create policy hospitals_delete_admin_if_no_referrals
  on public.hospitals for delete
  to authenticated
  using (
    private.can_manage_hospitals()
    and not exists (
      select 1 from public.hospital_referrals r where r.hospital_id = hospitals.id
    )
  );

-- 5. hospital_referrals: read-only admin visibility for the tracking view.
--    Nobody previously had SELECT on this table at all (by design, per its
--    existing comment) — this adds super_admin-only read access. No
--    write policy is added; it stays append-only exactly as designed.
create policy hospital_referrals_select_admin
  on public.hospital_referrals for select
  to authenticated
  using (private.can_manage_hospitals());

-- 6. Commission agreements — a SEPARATE table, deliberately not new columns
--    on hospitals. hospitals already has a public read policy
--    (hospitals_select_active); adding commission_rate directly to that
--    table would expose it to every user through that existing policy.
--    A separate table with no public policy at all is the only way to
--    guarantee commission data is never returned to a non-admin query.
create table public.hospital_commission_agreements (
  id uuid primary key default gen_random_uuid(),
  hospital_id uuid not null references public.hospitals(id) on delete cascade,
  commission_type text not null check (commission_type in ('percentage', 'flat_fee', 'none')),
  commission_rate numeric(10,2) check (commission_rate is null or commission_rate >= 0),
  agreement_status text not null default 'draft' check (agreement_status in ('draft','active','paused','ended')),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (hospital_id)
);

comment on table public.hospital_commission_agreements is 'Commercial commission terms per hospital (Basseer). Deliberately a separate table from hospitals with NO public read policy — commission_rate and agreement_status must never be exposed to normal users. One row per hospital for this foundational version.';

alter table public.hospital_commission_agreements enable row level security;

create trigger hospital_commission_agreements_set_updated_at
  before update on public.hospital_commission_agreements
  for each row execute function basseer_set_updated_at();

-- No policy at all for anon/authenticated -> default-deny. Only this one:
create policy hospital_commission_select_admin
  on public.hospital_commission_agreements for select
  to authenticated
  using (private.can_manage_hospitals());

create policy hospital_commission_insert_admin
  on public.hospital_commission_agreements for insert
  to authenticated
  with check (private.can_manage_hospitals());

create policy hospital_commission_update_admin
  on public.hospital_commission_agreements for update
  to authenticated
  using (private.can_manage_hospitals())
  with check (private.can_manage_hospitals());

create policy hospital_commission_delete_admin
  on public.hospital_commission_agreements for delete
  to authenticated
  using (private.can_manage_hospitals());

grant select, insert, update, delete on public.hospital_commission_agreements to authenticated;
revoke all on public.hospital_commission_agreements from anon;

-- 7. Storage: a new bucket for hospital logos. None of the existing
--    buckets fit (content-thumbnails is semantically for content items;
--    advertisements is for ad creatives; videos/avatars/profile are
--    private and unrelated).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('hospital-logos', 'hospital-logos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy hospital_logos_select_public
  on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'hospital-logos');

create policy hospital_logos_insert_admin
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'hospital-logos' and private.can_manage_hospitals());

create policy hospital_logos_update_admin
  on storage.objects for update
  to authenticated
  using (bucket_id = 'hospital-logos' and private.can_manage_hospitals())
  with check (bucket_id = 'hospital-logos' and private.can_manage_hospitals());

create policy hospital_logos_delete_admin
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'hospital-logos' and private.can_manage_hospitals());
