import { useState } from 'react'
import { ChevronDown, Lightbulb } from 'lucide-react'

interface TipPreviewProps {
  title: string
  summary: string | null
  fullContent: string | null
  imageUrl: string | null
}

/**
 * Approximates how a tip will render in the Basseer app: collapsed shows
 * image/icon + title + short summary, tapping expands to the full body.
 * This is a preview only — the actual user-app component is separate and
 * unchanged by this dashboard.
 */
export default function TipPreview({ title, summary, fullContent, imageUrl }: TipPreviewProps) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-surface">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="flex w-full items-center gap-3 p-4 text-left"
      >
        {imageUrl ? (
          <img src={imageUrl} alt="" className="h-12 w-12 shrink-0 rounded-lg border border-border object-cover" />
        ) : (
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-accent-soft text-accent">
            <Lightbulb size={20} />
          </div>
        )}
        <div className="min-w-0 flex-1">
          <p dir="auto" className="truncate font-semibold text-ink">
            {title || 'Untitled tip'}
          </p>
          {summary && (
            <p dir="auto" className="mt-0.5 truncate text-sm text-ink-muted">
              {summary}
            </p>
          )}
        </div>
        <ChevronDown
          size={18}
          className={`shrink-0 text-ink-faint transition-transform ${expanded ? 'rotate-180' : ''}`}
        />
      </button>

      {expanded && (
        <div className="border-t border-border px-4 py-4">
          {fullContent ? (
            <p dir="auto" className="whitespace-pre-wrap text-sm leading-relaxed text-ink">
              {fullContent}
            </p>
          ) : (
            <p className="text-sm text-ink-faint">No full content written yet.</p>
          )}
        </div>
      )}
    </div>
  )
}
