import { useEffect, useState, useCallback, useMemo } from 'react'
import { Plus, Pencil, Trash2, ChevronUp, ChevronDown, Eye, EyeOff, ImageOff, Sparkles } from 'lucide-react'
import type { ContentItem, ContentCategory } from '../../../types/content'
import { AUDIENCE_LABELS } from '../../../types/content'
import * as api from '../../../lib/contentApi'
import Modal from '../../../components/Modal'
import ConfirmDialog from '../../../components/ConfirmDialog'
import TipForm from '../../../components/content/TipForm'
import TipPreview from '../../../components/content/TipPreview'

export default function TipsPanel() {
  const [categories, setCategories] = useState<ContentCategory[]>([])
  const [tips, setTips] = useState<ContentItem[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [categoryFilter, setCategoryFilter] = useState<string>('all')

  const [formState, setFormState] = useState<{ mode: 'add' } | { mode: 'edit'; tip: ContentItem } | null>(null)
  const [previewTip, setPreviewTip] = useState<ContentItem | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<ContentItem | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      const [cats, items] = await Promise.all([api.listCategories(), api.listItems()])
      setCategories(cats)
      setTips(
        items.filter((i) => i.content_type === 'tip').sort((a, b) => a.sort_order - b.sort_order),
      )
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load tips.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const categoryNames = useMemo(() => {
    const map: Record<string, string> = {}
    for (const c of categories) map[c.id] = c.name
    return map
  }, [categories])

  const visibleTips = tips.filter((t) => categoryFilter === 'all' || t.category_id === categoryFilter)

  async function handleTogglePublished(tip: ContentItem) {
    setBusyId(tip.id)
    try {
      await api.setItemPublished(tip.id, !tip.is_published)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not update tip.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleMove(index: number, direction: -1 | 1) {
    const other = visibleTips[index + direction]
    if (!other) return
    const current = visibleTips[index]
    setBusyId(current.id)
    try {
      await api.swapItemOrder(current, other)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not reorder tips.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    setDeleteError(null)
    try {
      await api.deleteItem(deleteTarget.id)
      setDeleteTarget(null)
      await load()
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Could not delete tip.')
    } finally {
      setDeleting(false)
    }
  }

  async function handleFormSubmit(values: Parameters<typeof api.createItem>[0]) {
    if (formState?.mode === 'edit') {
      await api.updateItem(formState.tip.id, values)
    } else {
      await api.createItem(values)
    }
    setFormState(null)
    await load()
  }

  if (loading) {
    return <p className="text-sm text-ink-muted">Loading tips…</p>
  }

  if (categories.length === 0) {
    return (
      <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-6 text-center text-sm text-ink-faint">
        Add a category first, in the Categories tab — tips need one to belong to.
      </p>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-ink focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
        >
          <option value="all">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} · {AUDIENCE_LABELS[c.audience]}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => setFormState({ mode: 'add' })}
          className="flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-white hover:bg-accent-ink"
        >
          <Plus size={14} />
          Add tip
        </button>
      </div>

      {loadError && (
        <div className="rounded-lg border border-danger/20 bg-danger-soft px-4 py-3 text-sm text-danger">
          {loadError}
        </div>
      )}

      {visibleTips.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-10 text-center text-sm text-ink-faint">
          No tips yet.
        </p>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-surface">
          <table className="w-full text-sm">
            <tbody>
              {visibleTips.map((tip, index) => {
                const isBusy = busyId === tip.id
                return (
                  <tr key={tip.id} className={`border-b border-border last:border-0 ${isBusy ? 'opacity-50' : ''}`}>
                    <td className="w-16 px-3 py-3">
                      <div className="flex flex-col items-center gap-0.5">
                        <button
                          type="button"
                          disabled={index === 0 || isBusy}
                          onClick={() => handleMove(index, -1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move up"
                        >
                          <ChevronUp size={16} />
                        </button>
                        <button
                          type="button"
                          disabled={index === visibleTips.length - 1 || isBusy}
                          onClick={() => handleMove(index, 1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move down"
                        >
                          <ChevronDown size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="w-14 px-2 py-3">
                      {tip.thumbnail_url ? (
                        <img src={tip.thumbnail_url} alt="" className="h-10 w-10 rounded-lg border border-border object-cover" />
                      ) : (
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-dashed border-border bg-canvas text-ink-faint">
                          <ImageOff size={14} />
                        </div>
                      )}
                    </td>
                    <td className="px-2 py-3">
                      <p dir="auto" className="font-medium text-ink">
                        {tip.title}
                      </p>
                      <p dir="auto" className="mt-0.5 text-xs text-ink-faint">
                        {categoryNames[tip.category_id] ?? 'Unknown category'} · {AUDIENCE_LABELS[tip.audience]}
                      </p>
                    </td>
                    <td className="px-2 py-3">
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                          tip.is_published ? 'bg-success-soft text-success' : 'bg-warning-soft text-warning'
                        }`}
                      >
                        {tip.is_published ? 'Published' : 'Draft'}
                      </span>
                    </td>
                    <td className="px-2 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => setPreviewTip(tip)}
                          title="Preview"
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          <Sparkles size={15} />
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleTogglePublished(tip)}
                          title={tip.is_published ? 'Unpublish' : 'Publish'}
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          {tip.is_published ? <EyeOff size={15} /> : <Eye size={15} />}
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => setFormState({ mode: 'edit', tip })}
                          title="Edit"
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => {
                            setDeleteError(null)
                            setDeleteTarget(tip)
                          }}
                          title="Delete"
                          className="rounded-md p-1.5 text-ink-muted hover:bg-danger-soft hover:text-danger"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {formState && (
        <Modal title={formState.mode === 'edit' ? 'Edit tip' : 'Add tip'} maxWidthClass="max-w-xl" onClose={() => setFormState(null)}>
          <TipForm
            initial={formState.mode === 'edit' ? formState.tip : null}
            categories={categories}
            nextSortOrder={1 + Math.max(0, ...tips.map((t) => t.sort_order))}
            onSubmit={handleFormSubmit}
            onCancel={() => setFormState(null)}
          />
        </Modal>
      )}

      {previewTip && (
        <Modal title="Preview" onClose={() => setPreviewTip(null)}>
          <TipPreview
            title={previewTip.title}
            summary={previewTip.description}
            fullContent={previewTip.full_content}
            imageUrl={previewTip.thumbnail_url}
          />
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete tip?"
          message={`This permanently deletes "${deleteTarget.title}". This can't be undone.`}
          confirmLabel="Delete"
          danger
          busy={deleting}
          errorMessage={deleteError}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  )
}
