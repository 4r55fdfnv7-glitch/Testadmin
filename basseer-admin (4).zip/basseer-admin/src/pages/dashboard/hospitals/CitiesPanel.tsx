import { useEffect, useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, ChevronUp, ChevronDown, Eye, EyeOff } from 'lucide-react'
import type { City } from '../../../types/hospital'
import * as api from '../../../lib/hospitalApi'
import Modal from '../../../components/Modal'
import ConfirmDialog from '../../../components/ConfirmDialog'
import CityForm from '../../../components/hospitals/CityForm'

export default function CitiesPanel() {
  const [cities, setCities] = useState<City[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const [formState, setFormState] = useState<{ mode: 'add' } | { mode: 'edit'; city: City } | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<City | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      setCities(await api.listCities())
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load cities.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  async function handleToggleActive(city: City) {
    setBusyId(city.id)
    try {
      await api.updateCity(city.id, { is_active: !city.is_active })
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not update city.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleMove(index: number, direction: -1 | 1) {
    const other = cities[index + direction]
    if (!other) return
    const current = cities[index]
    setBusyId(current.id)
    try {
      await api.swapCityOrder(current, other)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not reorder cities.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    setDeleteError(null)
    try {
      await api.deleteCity(deleteTarget.id)
      setDeleteTarget(null)
      await load()
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Could not delete city.')
    } finally {
      setDeleting(false)
    }
  }

  async function handleFormSubmit(values: Parameters<typeof api.createCity>[0]) {
    if (formState?.mode === 'edit') {
      await api.updateCity(formState.city.id, values)
    } else {
      await api.createCity(values)
    }
    setFormState(null)
    await load()
  }

  if (loading) {
    return <p className="text-sm text-ink-muted">Loading cities…</p>
  }

  return (
    <div>
      {loadError && (
        <div className="mb-4 rounded-lg border border-danger/20 bg-danger-soft px-4 py-3 text-sm text-danger">
          {loadError}
        </div>
      )}

      <div className="mb-3 flex justify-end">
        <button
          type="button"
          onClick={() => setFormState({ mode: 'add' })}
          className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-ink hover:bg-canvas"
        >
          <Plus size={14} />
          Add city
        </button>
      </div>

      {cities.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-10 text-center text-sm text-ink-faint">
          No cities yet. Add one so hospitals can reference it.
        </p>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-surface">
          <table className="w-full text-sm">
            <tbody>
              {cities.map((city, index) => {
                const isBusy = busyId === city.id
                const count = city.hospital_count ?? 0
                return (
                  <tr key={city.id} className={`border-b border-border last:border-0 ${isBusy ? 'opacity-50' : ''}`}>
                    <td className="w-16 px-3 py-3">
                      <div className="flex flex-col items-center gap-0.5">
                        <button
                          type="button"
                          disabled={index === 0 || isBusy}
                          onClick={() => handleMove(index, -1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move up"
                        >
                          <ChevronUp size={16} />
                        </button>
                        <button
                          type="button"
                          disabled={index === cities.length - 1 || isBusy}
                          onClick={() => handleMove(index, 1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move down"
                        >
                          <ChevronDown size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="px-2 py-3">
                      <p dir="auto" className="font-medium text-ink">
                        {city.name}
                      </p>
                      <p className="mt-0.5 text-xs text-ink-faint">
                        {count} hospital{count === 1 ? '' : 's'}
                      </p>
                    </td>
                    <td className="px-2 py-3">
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                          city.is_active ? 'bg-success-soft text-success' : 'bg-canvas text-ink-faint'
                        }`}
                      >
                        {city.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-2 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleToggleActive(city)}
                          title={city.is_active ? 'Deactivate' : 'Activate'}
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          {city.is_active ? <EyeOff size={15} /> : <Eye size={15} />}
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => setFormState({ mode: 'edit', city })}
                          title="Edit"
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => {
                            setDeleteError(null)
                            setDeleteTarget(city)
                          }}
                          title={count > 0 ? `${count} hospital(s) use this city` : 'Delete'}
                          className="rounded-md p-1.5 text-ink-muted hover:bg-danger-soft hover:text-danger"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {formState && (
        <Modal title={formState.mode === 'edit' ? 'Edit city' : 'Add city'} onClose={() => setFormState(null)}>
          <CityForm
            initial={formState.mode === 'edit' ? formState.city : null}
            nextSortOrder={1 + Math.max(0, ...cities.map((c) => c.sort_order))}
            onSubmit={handleFormSubmit}
            onCancel={() => setFormState(null)}
          />
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete city?"
          message={
            (deleteTarget.hospital_count ?? 0) > 0
              ? `"${deleteTarget.name}" is used by ${deleteTarget.hospital_count} hospital(s). Deleting is blocked while that's true — move those hospitals to a different city first, or deactivate this city instead.`
              : `This permanently deletes "${deleteTarget.name}". This can't be undone.`
          }
          confirmLabel="Delete"
          danger
          busy={deleting}
          errorMessage={deleteError}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  )
}
