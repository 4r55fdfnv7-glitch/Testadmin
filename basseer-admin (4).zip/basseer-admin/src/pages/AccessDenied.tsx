import { ShieldAlert } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'

export default function AccessDenied() {
  const { session, signOut } = useAuth()

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-8 text-center shadow-card">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-danger-soft text-danger">
          <ShieldAlert size={22} />
        </div>

        <p dir="rtl" className="mt-5 text-lg font-bold text-ink">
          غير مصرح لك بالوصول
        </p>
        <p className="mt-1 text-sm text-ink-muted">You're not authorized to access this admin dashboard.</p>

        {session?.user.email && (
          <p className="mt-4 text-xs text-ink-faint">
            Signed in as <span className="font-medium text-ink-muted">{session.user.email}</span>
          </p>
        )}

        <p className="mt-2 text-xs text-ink-faint">
          If you believe this is a mistake, ask a super admin to grant your account a role.
        </p>

        <button
          type="button"
          onClick={() => void signOut()}
          className="mt-6 w-full rounded-lg border border-border px-4 py-2.5 text-sm font-semibold text-ink transition-colors hover:bg-canvas"
        >
          Sign in with a different account
        </button>
      </div>
    </div>
  )
}
