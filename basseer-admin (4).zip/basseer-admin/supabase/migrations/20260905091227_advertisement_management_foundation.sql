-- =========================================================
-- Basseer Admin Dashboard — Advertisement Management
-- Applied to project dffbbjstorpxjrjhyhwt.
-- Purely additive on top of the existing public.advertisements table and
-- the existing "advertisements" storage bucket. Does not touch the existing
-- advertisements_select_visible policy the user app's carousel depends on.
-- =========================================================

-- 1. Authorization helper. Advertisements are a super_admin-only capability
--    per the original role design (content_editor's remit is content, not
--    ads) — thin wrapper for naming clarity and so this can be loosened
--    later (e.g. a future "marketing" role) by editing one function.
create or replace function private.can_manage_ads()
returns boolean
language sql
security definer
stable
set search_path = public, private
as $$
  select private.is_super_admin();
$$;

comment on function private.can_manage_ads() is 'True if the current user may manage advertisements. Currently super_admin only.';

-- 2. Table policies. The existing advertisements_select_visible policy
--    (anon+authenticated, active+in-window rows only) is untouched — this
--    ADDS admin visibility into every row (including scheduled/expired/
--    inactive) plus write access, gated by can_manage_ads().
create policy advertisements_select_admin
  on public.advertisements for select
  to authenticated
  using (private.can_manage_ads());

create policy advertisements_insert_admin
  on public.advertisements for insert
  to authenticated
  with check (private.can_manage_ads());

create policy advertisements_update_admin
  on public.advertisements for update
  to authenticated
  using (private.can_manage_ads())
  with check (private.can_manage_ads());

create policy advertisements_delete_admin
  on public.advertisements for delete
  to authenticated
  using (private.can_manage_ads());

-- 3. Storage: reuse the existing "advertisements" bucket (already public,
--    already has a SELECT policy the carousel relies on). It currently has
--    no size/type limits at all; tighten those since it's used for exactly
--    one purpose, then add admin-only write policies (none existed before).
update storage.buckets
set file_size_limit = 5242880,
    allowed_mime_types = array['image/jpeg','image/png','image/webp']
where id = 'advertisements';

create policy advertisements_storage_insert_admin
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'advertisements' and private.can_manage_ads());

create policy advertisements_storage_update_admin
  on storage.objects for update
  to authenticated
  using (bucket_id = 'advertisements' and private.can_manage_ads())
  with check (bucket_id = 'advertisements' and private.can_manage_ads());

create policy advertisements_storage_delete_admin
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'advertisements' and private.can_manage_ads());
