// Mirrors public.cities / public.hospitals / public.hospital_commission_agreements
// / public.hospital_referrals exactly.

export interface City {
  id: string
  name: string
  is_active: boolean
  sort_order: number
  created_at: string
  updated_at: string
  /** Not a DB column — attached client-side from an embedded count query. */
  hospital_count?: number
}

export interface CityInput {
  name: string
  is_active: boolean
  sort_order: number
}

export interface Hospital {
  id: string
  name: string
  city: string // kept in sync from city_id by a DB trigger — read-only here
  city_id: string
  address: string | null
  phone: string | null
  description: string | null
  image_url: string | null
  booking_url: string | null
  is_active: boolean
  sort_order: number
  created_at: string
  updated_at: string
  /** Not columns — attached client-side. */
  city_name?: string
  referral_count?: number
}

// city (text) is deliberately omitted — it's derived server-side and the
// dashboard only ever sets city_id.
export interface HospitalInput {
  name: string
  city_id: string
  address: string | null
  phone: string | null
  description: string | null
  image_url: string | null
  booking_url: string | null
  is_active: boolean
  sort_order: number
}

export type CommissionType = 'percentage' | 'flat_fee' | 'none'
export type AgreementStatus = 'draft' | 'active' | 'paused' | 'ended'

export interface CommissionAgreement {
  id: string
  hospital_id: string
  commission_type: CommissionType
  commission_rate: number | null
  agreement_status: AgreementStatus
  notes: string | null
  created_at: string
  updated_at: string
}

export interface CommissionAgreementInput {
  commission_type: CommissionType
  commission_rate: number | null
  agreement_status: AgreementStatus
  notes: string | null
}

export interface HospitalReferral {
  id: string
  hospital_id: string
  user_id: string | null
  clicked_at: string
  booking_started_at: string | null
}

// Aggregated row for the referral tracking view — computed client-side from
// raw hospital_referrals rows, not a database view.
export interface ReferralSummaryRow {
  hospital_id: string
  hospital_name: string
  date: string // YYYY-MM-DD, local grouping key
  click_count: number
  booking_started_count: number
}
