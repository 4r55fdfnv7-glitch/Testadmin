import { supabase } from './supabase'
import { optimizeImage } from './imageOptimize'
import type {
  City,
  CityInput,
  Hospital,
  HospitalInput,
  CommissionAgreement,
  CommissionAgreementInput,
  ReferralSummaryRow,
} from '../types/hospital'

const LOGO_BUCKET = 'hospital-logos'
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024
const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp'])

function unwrap<T>({ data, error }: { data: T; error: { message: string } | null }): T {
  if (error) throw new Error(error.message)
  return data
}

// ---------------------------------------------------------------------------
// Cities
// ---------------------------------------------------------------------------

export async function listCities(): Promise<City[]> {
  const [citiesRes, hospitalsRes] = await Promise.all([
    supabase.from('cities').select('*').order('sort_order', { ascending: true }),
    supabase.from('hospitals').select('city_id'),
  ])
  const cities = unwrap(citiesRes) ?? []
  const hospitals = (unwrap(hospitalsRes) ?? []) as { city_id: string }[]
  const counts: Record<string, number> = {}
  for (const h of hospitals) counts[h.city_id] = (counts[h.city_id] ?? 0) + 1
  return cities.map((c) => ({ ...c, hospital_count: counts[c.id] ?? 0 }))
}

export async function createCity(input: CityInput): Promise<City> {
  const res = await supabase.from('cities').insert(input).select().single()
  return unwrap(res)
}

export async function updateCity(id: string, input: Partial<CityInput>): Promise<City> {
  const res = await supabase.from('cities').update(input).eq('id', id).select().maybeSingle()
  const row = unwrap(res)
  if (!row) throw new Error("Couldn't save — this city may have been changed or removed elsewhere.")
  return row
}

export async function deleteCity(id: string): Promise<void> {
  const res = await supabase.from('cities').delete().eq('id', id).select()
  const rows = unwrap(res)
  if (!rows || rows.length === 0) {
    throw new Error(
      "Couldn't delete — one or more hospitals still use this city, or it was already removed. " +
        'Move those hospitals to a different city first, or deactivate this one instead.',
    )
  }
}

export async function swapCityOrder(a: City, b: City): Promise<void> {
  unwrap(await supabase.from('cities').update({ sort_order: b.sort_order }).eq('id', a.id).select())
  unwrap(await supabase.from('cities').update({ sort_order: a.sort_order }).eq('id', b.id).select())
}

// ---------------------------------------------------------------------------
// Hospitals
// ---------------------------------------------------------------------------

export async function listHospitals(): Promise<Hospital[]> {
  const [hospitalsRes, citiesRes, referralsRes] = await Promise.all([
    supabase.from('hospitals').select('*').order('sort_order', { ascending: true }),
    supabase.from('cities').select('id, name'),
    supabase.from('hospital_referrals').select('hospital_id'),
  ])
  const hospitals = unwrap(hospitalsRes) ?? []
  const cities = (unwrap(citiesRes) ?? []) as { id: string; name: string }[]
  const referrals = (unwrap(referralsRes) ?? []) as { hospital_id: string }[]

  const cityNames: Record<string, string> = {}
  for (const c of cities) cityNames[c.id] = c.name
  const refCounts: Record<string, number> = {}
  for (const r of referrals) refCounts[r.hospital_id] = (refCounts[r.hospital_id] ?? 0) + 1

  return hospitals.map((h) => ({
    ...h,
    city_name: cityNames[h.city_id] ?? h.city,
    referral_count: refCounts[h.id] ?? 0,
  }))
}

export async function createHospital(input: HospitalInput): Promise<Hospital> {
  const res = await supabase.from('hospitals').insert(input).select().single()
  return unwrap(res)
}

export async function updateHospital(id: string, input: Partial<HospitalInput>): Promise<Hospital> {
  const res = await supabase.from('hospitals').update(input).eq('id', id).select().maybeSingle()
  const row = unwrap(res)
  if (!row) throw new Error("Couldn't save — this hospital may have been changed or removed elsewhere.")
  return row
}

export async function deleteHospital(id: string): Promise<void> {
  const res = await supabase.from('hospitals').delete().eq('id', id).select()
  const rows = unwrap(res)
  if (!rows || rows.length === 0) {
    throw new Error(
      "Couldn't delete — this hospital has referral history, or it was already removed. " +
        'Deactivate it instead to keep that history intact.',
    )
  }
}

export async function swapHospitalOrder(a: Hospital, b: Hospital): Promise<void> {
  unwrap(await supabase.from('hospitals').update({ sort_order: b.sort_order }).eq('id', a.id).select())
  unwrap(await supabase.from('hospitals').update({ sort_order: a.sort_order }).eq('id', b.id).select())
}

export async function uploadHospitalLogo(file: File): Promise<string> {
  if (!ALLOWED_TYPES.has(file.type)) {
    throw new Error('Please choose a JPEG, PNG, or WebP image.')
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new Error('That image is larger than 5MB — please choose a smaller file.')
  }

  const optimized = await optimizeImage(file)
  const ext = optimized.name.split('.').pop()?.toLowerCase() || 'jpg'
  const path = `${crypto.randomUUID()}.${ext}`

  const { error } = await supabase.storage.from(LOGO_BUCKET).upload(path, optimized, {
    cacheControl: '31536000',
    upsert: false,
    contentType: optimized.type,
  })
  if (error) throw new Error(error.message)

  const { data } = supabase.storage.from(LOGO_BUCKET).getPublicUrl(path)
  return data.publicUrl
}

// ---------------------------------------------------------------------------
// Commission agreements — super_admin only, never exposed to public queries.
// One row per hospital (unique(hospital_id) in the database).
// ---------------------------------------------------------------------------

export async function getCommissionAgreement(hospitalId: string): Promise<CommissionAgreement | null> {
  const res = await supabase
    .from('hospital_commission_agreements')
    .select('*')
    .eq('hospital_id', hospitalId)
    .maybeSingle()
  return unwrap(res)
}

export async function saveCommissionAgreement(
  hospitalId: string,
  input: CommissionAgreementInput,
): Promise<CommissionAgreement> {
  const res = await supabase
    .from('hospital_commission_agreements')
    .upsert({ hospital_id: hospitalId, ...input }, { onConflict: 'hospital_id' })
    .select()
    .single()
  return unwrap(res)
}

// ---------------------------------------------------------------------------
// Referral tracking — read-only aggregation over the append-only log.
// ---------------------------------------------------------------------------

export async function listReferralSummary(): Promise<ReferralSummaryRow[]> {
  const [referralsRes, hospitalsRes] = await Promise.all([
    supabase
      .from('hospital_referrals')
      .select('hospital_id, clicked_at, booking_started_at')
      .order('clicked_at', { ascending: false }),
    supabase.from('hospitals').select('id, name'),
  ])
  const referrals = unwrap(referralsRes) ?? []
  const hospitals = (unwrap(hospitalsRes) ?? []) as { id: string; name: string }[]
  const names: Record<string, string> = {}
  for (const h of hospitals) names[h.id] = h.name

  const grouped: Record<string, ReferralSummaryRow> = {}
  for (const r of referrals as { hospital_id: string; clicked_at: string; booking_started_at: string | null }[]) {
    const date = r.clicked_at.slice(0, 10)
    const key = `${r.hospital_id}|${date}`
    if (!grouped[key]) {
      grouped[key] = {
        hospital_id: r.hospital_id,
        hospital_name: names[r.hospital_id] ?? 'Unknown hospital',
        date,
        click_count: 0,
        booking_started_count: 0,
      }
    }
    grouped[key].click_count += 1
    if (r.booking_started_at) grouped[key].booking_started_count += 1
  }

  return Object.values(grouped).sort((a, b) => (a.date < b.date ? 1 : -1))
}
