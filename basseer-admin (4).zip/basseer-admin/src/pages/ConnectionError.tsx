import { WifiOff } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'

export default function ConnectionError() {
  const { errorMessage, retry } = useAuth()

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-8 text-center shadow-card">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-warning-soft text-warning">
          <WifiOff size={22} />
        </div>
        <h1 className="mt-5 text-lg font-bold text-ink">Connection problem</h1>
        <p className="mt-1 text-sm text-ink-muted">
          {errorMessage ?? 'Could not reach Basseer. Check your connection and try again.'}
        </p>
        <button
          type="button"
          onClick={retry}
          className="mt-6 w-full rounded-lg bg-accent px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-accent-ink"
        >
          Retry
        </button>
      </div>
    </div>
  )
}
