import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import AdminLayout from './components/layout/AdminLayout'
import Login from './pages/Login'
import NotFound from './pages/NotFound'
import Overview from './pages/dashboard/Overview'
import Content from './pages/dashboard/Content'
import Advertisements from './pages/dashboard/Advertisements'
import Hospitals from './pages/dashboard/Hospitals'
import Users from './pages/dashboard/Users'
import Assessments from './pages/dashboard/Assessments'
import Settings from './pages/dashboard/Settings'

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />

          <Route
            path="/"
            element={
              <ProtectedRoute>
                <AdminLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Overview />} />
            <Route path="content" element={<Content />} />
            <Route path="advertisements" element={<Advertisements />} />
            <Route path="hospitals" element={<Hospitals />} />
            <Route path="users" element={<Users />} />
            <Route path="assessments" element={<Assessments />} />
            <Route path="settings" element={<Settings />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  )
}
