import type { LucideIcon } from 'lucide-react'

interface StatCardProps {
  label: string
  value: string | number | null
  icon: LucideIcon
  hint?: string
}

export default function StatCard({ label, value, icon: Icon, hint }: StatCardProps) {
  const display = value === null || value === undefined ? '--' : value

  return (
    <div className="rounded-xl border border-border bg-surface p-5 shadow-card">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-ink-muted">{label}</p>
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent-soft text-accent">
          <Icon size={16} />
        </span>
      </div>
      <p className="mt-3 text-2xl font-bold tabular-nums text-ink">{display}</p>
      {hint && <p className="mt-1 text-xs text-ink-faint">{hint}</p>}
    </div>
  )
}
