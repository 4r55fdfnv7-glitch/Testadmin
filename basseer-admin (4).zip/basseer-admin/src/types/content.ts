// Mirrors public.content_categories / public.content_items exactly as they
// exist in Supabase — see supabase/migrations for the source of truth.
// Do not add fields here that don't exist in the database.

export type Audience = 'parent' | 'child' | 'both'
export type ContentType = 'video' | 'article' | 'activity' | 'resource' | 'tip'

export interface ContentCategory {
  id: string
  name: string
  description: string | null
  audience: Audience
  is_active: boolean
  sort_order: number
  created_at: string
  updated_at: string
}

export interface ContentItem {
  id: string
  category_id: string
  title: string
  description: string | null
  // Long-form body. Used by tips (content_type = 'tip'); optional for
  // other content types.
  full_content: string | null
  content_type: ContentType
  content_url: string | null
  thumbnail_url: string | null
  // Derived automatically from the category by a database trigger
  // (content_items_sync_audience) — never send this on insert/update,
  // the database overwrites it regardless.
  audience: Audience
  is_published: boolean
  sort_order: number
  created_at: string
  updated_at: string
}

export type ContentCategoryInput = {
  name: string
  description: string | null
  audience: Audience
  sort_order: number
  is_active: boolean
}

export type ContentItemInput = {
  category_id: string
  title: string
  description: string | null
  full_content: string | null
  content_type: ContentType
  content_url: string | null
  thumbnail_url: string | null
  sort_order: number
  is_published: boolean
}

export const AUDIENCE_LABELS: Record<Audience, string> = {
  parent: 'Parents',
  child: 'Children',
  both: 'Both',
}

export const CONTENT_TYPE_LABELS: Record<ContentType, string> = {
  video: 'Video',
  article: 'Article',
  activity: 'Activity',
  resource: 'Resource',
  tip: 'Tip',
}
