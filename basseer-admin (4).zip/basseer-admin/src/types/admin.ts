// Mirrors public.admin_roles.role's CHECK constraint. If you add a role in the
// database (see migration notes), add it here too so the UI stays in sync.
export type AdminRoleName = 'super_admin' | 'content_editor' | 'support'

export interface AdminRoleRow {
  id: string
  user_id: string
  role: AdminRoleName
  created_at: string
  created_by: string | null
}

// Resolution states for "is the current visitor allowed into the dashboard".
// Kept distinct from plain booleans so ProtectedRoute can render the right
// thing for each case instead of collapsing them into one generic "no".
export type AuthStatus =
  | 'loading' // session not yet resolved — render nothing protected
  | 'unauthenticated' // no Supabase session at all
  | 'unauthorized' // valid Supabase session, but zero admin_roles rows
  | 'authorized' // valid session with at least one admin_roles row
  | 'error' // couldn't resolve (network/Supabase issue) — distinct from unauthorized
