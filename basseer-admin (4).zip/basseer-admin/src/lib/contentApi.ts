import { supabase } from './supabase'
import type {
  ContentCategory,
  ContentItem,
  ContentCategoryInput,
  ContentItemInput,
} from '../types/content'

const THUMBNAIL_BUCKET = 'content-thumbnails'
const MAX_THUMBNAIL_BYTES = 5 * 1024 * 1024
const ALLOWED_THUMBNAIL_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp'])

/** Throws a clean Error with Supabase's message if the response carried one. */
function unwrap<T>({ data, error }: { data: T; error: { message: string } | null }): T {
  if (error) throw new Error(error.message)
  return data
}

// ---------------------------------------------------------------------------
// Categories
// ---------------------------------------------------------------------------

export async function listCategories(): Promise<ContentCategory[]> {
  const res = await supabase
    .from('content_categories')
    .select('*')
    .order('audience', { ascending: true })
    .order('sort_order', { ascending: true })
  return unwrap(res) ?? []
}

export async function createCategory(input: ContentCategoryInput): Promise<ContentCategory> {
  const res = await supabase.from('content_categories').insert(input).select().single()
  return unwrap(res)
}

export async function updateCategory(
  id: string,
  input: Partial<ContentCategoryInput>,
): Promise<ContentCategory> {
  const res = await supabase
    .from('content_categories')
    .update(input)
    .eq('id', id)
    .select()
    .maybeSingle()
  const row = unwrap(res)
  if (!row) {
    throw new Error("Couldn't update — this category may have been changed or removed elsewhere.")
  }
  return row
}

export async function deleteCategory(id: string): Promise<void> {
  // RLS (content_categories_delete_admin_if_empty) silently blocks this with
  // 0 rows affected — rather than an error — when the category still has
  // content items. Detect that here and turn it into a clear message.
  const res = await supabase.from('content_categories').delete().eq('id', id).select()
  const rows = unwrap(res)
  if (!rows || rows.length === 0) {
    throw new Error(
      "Couldn't delete — this category still has content items, or it was already removed. " +
        'Move or delete its items first, or deactivate the category instead.',
    )
  }
}

export async function swapCategoryOrder(a: ContentCategory, b: ContentCategory): Promise<void> {
  const first = await supabase
    .from('content_categories')
    .update({ sort_order: b.sort_order })
    .eq('id', a.id)
    .select()
  unwrap(first)
  const second = await supabase
    .from('content_categories')
    .update({ sort_order: a.sort_order })
    .eq('id', b.id)
    .select()
  unwrap(second)
}

export async function countItemsByCategory(): Promise<Record<string, number>> {
  const res = await supabase.from('content_items').select('category_id')
  const rows = unwrap(res) ?? []
  const counts: Record<string, number> = {}
  for (const row of rows as { category_id: string }[]) {
    counts[row.category_id] = (counts[row.category_id] ?? 0) + 1
  }
  return counts
}

// ---------------------------------------------------------------------------
// Content items
// ---------------------------------------------------------------------------

export async function listItems(): Promise<ContentItem[]> {
  const res = await supabase
    .from('content_items')
    .select('*')
    .order('sort_order', { ascending: true })
  return unwrap(res) ?? []
}

export async function createItem(input: ContentItemInput): Promise<ContentItem> {
  // audience is intentionally omitted — the basseer_content_items_sync_audience
  // trigger derives it from category_id and overwrites whatever is sent anyway.
  const res = await supabase.from('content_items').insert(input).select().single()
  return unwrap(res)
}

export async function updateItem(
  id: string,
  input: Partial<ContentItemInput>,
): Promise<ContentItem> {
  const res = await supabase.from('content_items').update(input).eq('id', id).select().maybeSingle()
  const row = unwrap(res)
  if (!row) {
    throw new Error("Couldn't save — this item may have been changed or removed elsewhere.")
  }
  return row
}

export async function deleteItem(id: string): Promise<void> {
  const res = await supabase.from('content_items').delete().eq('id', id).select()
  const rows = unwrap(res)
  if (!rows || rows.length === 0) {
    throw new Error("Couldn't delete — this item may have already been removed.")
  }
}

export async function setItemPublished(id: string, value: boolean): Promise<void> {
  await updateItem(id, { is_published: value })
}

export async function swapItemOrder(a: ContentItem, b: ContentItem): Promise<void> {
  const first = await supabase
    .from('content_items')
    .update({ sort_order: b.sort_order })
    .eq('id', a.id)
    .select()
  unwrap(first)
  const second = await supabase
    .from('content_items')
    .update({ sort_order: a.sort_order })
    .eq('id', b.id)
    .select()
  unwrap(second)
}

// ---------------------------------------------------------------------------
// Storage — thumbnails
// ---------------------------------------------------------------------------

export async function uploadThumbnail(file: File): Promise<string> {
  if (!ALLOWED_THUMBNAIL_TYPES.has(file.type)) {
    throw new Error('Please choose a JPEG, PNG, or WebP image.')
  }
  if (file.size > MAX_THUMBNAIL_BYTES) {
    throw new Error('That image is larger than 5MB — please choose a smaller file.')
  }

  const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg'
  const path = `${crypto.randomUUID()}.${ext}`

  const { error } = await supabase.storage.from(THUMBNAIL_BUCKET).upload(path, file, {
    cacheControl: '31536000',
    upsert: false,
    contentType: file.type,
  })
  if (error) throw new Error(error.message)

  const { data } = supabase.storage.from(THUMBNAIL_BUCKET).getPublicUrl(path)
  return data.publicUrl
}
