import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react'
import { Upload, Lock } from 'lucide-react'
import type {
  Hospital,
  HospitalInput,
  City,
  CommissionAgreement,
  CommissionAgreementInput,
  CommissionType,
  AgreementStatus,
} from '../../types/hospital'
import { uploadHospitalLogo, getCommissionAgreement, saveCommissionAgreement } from '../../lib/hospitalApi'
import { validateSafeUrl } from '../../lib/urlValidation'

interface HospitalFormProps {
  initial?: Hospital | null
  cities: City[]
  nextSortOrder: number
  onSubmit: (values: HospitalInput) => Promise<void>
  onCancel: () => void
}

const COMMISSION_TYPES: { value: CommissionType; label: string }[] = [
  { value: 'none', label: 'No commission' },
  { value: 'percentage', label: 'Percentage of booking' },
  { value: 'flat_fee', label: 'Flat fee' },
]
const AGREEMENT_STATUSES: { value: AgreementStatus; label: string }[] = [
  { value: 'draft', label: 'Draft' },
  { value: 'active', label: 'Active' },
  { value: 'paused', label: 'Paused' },
  { value: 'ended', label: 'Ended' },
]

export default function HospitalForm({ initial, cities, nextSortOrder, onSubmit, onCancel }: HospitalFormProps) {
  const [name, setName] = useState(initial?.name ?? '')
  const [cityId, setCityId] = useState(initial?.city_id ?? cities[0]?.id ?? '')
  const [address, setAddress] = useState(initial?.address ?? '')
  const [phone, setPhone] = useState(initial?.phone ?? '')
  const [description, setDescription] = useState(initial?.description ?? '')
  const [imageUrl, setImageUrl] = useState(initial?.image_url ?? '')
  const [bookingUrl, setBookingUrl] = useState(initial?.booking_url ?? '')
  const [isActive, setIsActive] = useState(initial?.is_active ?? false)
  const [sortOrder, setSortOrder] = useState(initial?.sort_order ?? nextSortOrder)
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Commission — only meaningful once the hospital exists.
  const [commissionType, setCommissionType] = useState<CommissionType>('none')
  const [commissionRate, setCommissionRate] = useState('')
  const [agreementStatus, setAgreementStatus] = useState<AgreementStatus>('draft')
  const [commissionNotes, setCommissionNotes] = useState('')
  const [commissionLoaded, setCommissionLoaded] = useState(!initial)
  const [savingCommission, setSavingCommission] = useState(false)
  const [commissionSaved, setCommissionSaved] = useState(false)
  const [commissionError, setCommissionError] = useState<string | null>(null)

  useEffect(() => {
    if (!initial) return
    let cancelled = false
    getCommissionAgreement(initial.id)
      .then((agreement: CommissionAgreement | null) => {
        if (cancelled || !agreement) return
        setCommissionType(agreement.commission_type)
        setCommissionRate(agreement.commission_rate?.toString() ?? '')
        setAgreementStatus(agreement.agreement_status)
        setCommissionNotes(agreement.notes ?? '')
      })
      .finally(() => {
        if (!cancelled) setCommissionLoaded(true)
      })
    return () => {
      cancelled = true
    }
  }, [initial])

  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError(null)
    try {
      setImageUrl(await uploadHospitalLogo(file))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed. Please try again.')
    } finally {
      setUploading(false)
    }
  }

  async function handleSaveCommission() {
    if (!initial) return
    const rate = commissionRate.trim() === '' ? null : Number(commissionRate)
    if (rate !== null && (Number.isNaN(rate) || rate < 0)) {
      setCommissionError('Commission rate must be a positive number.')
      return
    }
    setSavingCommission(true)
    setCommissionError(null)
    setCommissionSaved(false)
    try {
      const input: CommissionAgreementInput = {
        commission_type: commissionType,
        commission_rate: rate,
        agreement_status: agreementStatus,
        notes: commissionNotes.trim() || null,
      }
      await saveCommissionAgreement(initial.id, input)
      setCommissionSaved(true)
    } catch (err) {
      setCommissionError(err instanceof Error ? err.message : 'Could not save commission terms.')
    } finally {
      setSavingCommission(false)
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!name.trim()) {
      setError('Hospital name is required.')
      return
    }
    if (!cityId) {
      setError('Choose a city — add one first if the list is empty.')
      return
    }
    const bookingCheck = validateSafeUrl(bookingUrl)
    if (!bookingCheck.valid) {
      setError(bookingCheck.reason)
      return
    }

    setSubmitting(true)
    setError(null)
    try {
      await onSubmit({
        name: name.trim(),
        city_id: cityId,
        address: address.trim() || null,
        phone: phone.trim() || null,
        description: description.trim() || null,
        image_url: imageUrl.trim() || null,
        booking_url: bookingUrl.trim() || null,
        is_active: isActive,
        sort_order: sortOrder,
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Logo (optional)</label>
          <div className="flex items-center gap-3">
            {imageUrl ? (
              <img src={imageUrl} alt="" className="h-16 w-16 shrink-0 rounded-lg border border-border object-cover" />
            ) : (
              <div className="h-16 w-16 shrink-0 rounded-lg border border-dashed border-border bg-canvas" />
            )}
            <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-ink hover:bg-canvas">
              <Upload size={14} />
              {uploading ? 'Uploading…' : imageUrl ? 'Replace logo' : 'Upload logo'}
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={handleFileChange}
                disabled={uploading}
              />
            </label>
          </div>
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Name</label>
          <input
            dir="auto"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">City</label>
          {cities.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border bg-canvas px-3.5 py-2.5 text-sm text-ink-faint">
              No cities yet — add one in the Cities tab first.
            </p>
          ) : (
            <select
              value={cityId}
              onChange={(e) => setCityId(e.target.value)}
              className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
            >
              {cities.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Address (optional)</label>
          <input
            dir="auto"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Phone (optional)</label>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Description (optional)</label>
          <textarea
            dir="auto"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Booking URL (optional)</label>
          <input
            value={bookingUrl}
            onChange={(e) => setBookingUrl(e.target.value)}
            placeholder="https://…"
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
          <p className="mt-1 text-xs text-ink-faint">Only plain http:// or https:// links are accepted.</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-ink">Sort order</label>
            <input
              type="number"
              value={sortOrder}
              onChange={(e) => setSortOrder(Number(e.target.value))}
              className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
            />
          </div>
          <div className="flex items-end pb-2.5">
            <label className="flex items-center gap-2 text-sm font-medium text-ink">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="h-4 w-4 rounded border-border text-accent focus:ring-accent"
              />
              Active
            </label>
          </div>
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <div className="flex justify-end gap-2 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg border border-border px-4 py-2 text-sm font-semibold text-ink hover:bg-canvas"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting || uploading || cities.length === 0}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white hover:bg-accent-ink disabled:opacity-60"
          >
            {submitting ? 'Saving…' : initial ? 'Save changes' : 'Add hospital'}
          </button>
        </div>
      </form>

      <div className="rounded-lg border border-border bg-canvas p-4">
        <div className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-ink">
          <Lock size={13} className="text-ink-faint" />
          Commission (internal — never shown to users)
        </div>

        {!initial ? (
          <p className="text-sm text-ink-faint">Save this hospital first, then set its commission terms here.</p>
        ) : !commissionLoaded ? (
          <p className="text-sm text-ink-faint">Loading…</p>
        ) : (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-ink-muted">Type</label>
                <select
                  value={commissionType}
                  onChange={(e) => setCommissionType(e.target.value as CommissionType)}
                  className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
                >
                  {COMMISSION_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-ink-muted">
                  Rate {commissionType === 'percentage' ? '(%)' : commissionType === 'flat_fee' ? '(amount)' : ''}
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  disabled={commissionType === 'none'}
                  value={commissionRate}
                  onChange={(e) => setCommissionRate(e.target.value)}
                  className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent disabled:opacity-50"
                />
              </div>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-ink-muted">Agreement status</label>
              <select
                value={agreementStatus}
                onChange={(e) => setAgreementStatus(e.target.value as AgreementStatus)}
                className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
              >
                {AGREEMENT_STATUSES.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-ink-muted">Notes (optional)</label>
              <textarea
                dir="auto"
                value={commissionNotes}
                onChange={(e) => setCommissionNotes(e.target.value)}
                rows={2}
                className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
              />
            </div>
            {commissionError && <p className="text-sm text-danger">{commissionError}</p>}
            {commissionSaved && <p className="text-sm text-success">Commission terms saved.</p>}
            <button
              type="button"
              onClick={handleSaveCommission}
              disabled={savingCommission}
              className="rounded-lg border border-border bg-surface px-3.5 py-2 text-sm font-semibold text-ink hover:bg-canvas disabled:opacity-60"
            >
              {savingCommission ? 'Saving…' : 'Save commission terms'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
