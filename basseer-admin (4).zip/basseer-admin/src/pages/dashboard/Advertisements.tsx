import { useCallback, useEffect, useState } from 'react'
import { ShieldAlert, Plus, Pencil, Trash2, ChevronUp, ChevronDown, Eye, EyeOff, ExternalLink } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import type { Advertisement } from '../../types/advertisement'
import { computeAdStatus } from '../../types/advertisement'
import * as api from '../../lib/advertisementApi'
import Modal from '../../components/Modal'
import ConfirmDialog from '../../components/ConfirmDialog'
import AdvertisementForm from '../../components/advertisements/AdvertisementForm'

const STATUS_STYLES: Record<string, string> = {
  live: 'bg-success-soft text-success',
  scheduled: 'bg-accent-soft text-accent-ink',
  expired: 'bg-canvas text-ink-faint',
  inactive: 'bg-canvas text-ink-faint',
}
const STATUS_LABELS: Record<string, string> = {
  live: 'Live',
  scheduled: 'Scheduled',
  expired: 'Expired',
  inactive: 'Inactive',
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleString(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  })
}

export default function Advertisements() {
  const { isSuperAdmin } = useAuth()

  const [ads, setAds] = useState<Advertisement[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const [formState, setFormState] = useState<{ mode: 'add' } | { mode: 'edit'; ad: Advertisement } | null>(
    null,
  )
  const [deleteTarget, setDeleteTarget] = useState<Advertisement | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      setAds(await api.listAdvertisements())
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load advertisements.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (isSuperAdmin) void load()
  }, [isSuperAdmin, load])

  if (!isSuperAdmin) {
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center rounded-xl border border-dashed border-border bg-surface px-6 py-16 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning-soft text-warning">
          <ShieldAlert size={22} />
        </div>
        <h2 className="mt-4 text-lg font-bold text-ink">Super admin access required</h2>
        <p className="mt-1.5 max-w-sm text-sm text-ink-muted">
          Advertisement management is restricted to super admins. Ask a super admin if you need
          access.
        </p>
      </div>
    )
  }

  async function handleToggleActive(ad: Advertisement) {
    setBusyId(ad.id)
    try {
      await api.updateAdvertisement(ad.id, { is_active: !ad.is_active })
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not update advertisement.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleMove(index: number, direction: -1 | 1) {
    const other = ads[index + direction]
    if (!other) return
    const current = ads[index]
    setBusyId(current.id)
    try {
      await api.swapAdvertisementOrder(current, other)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not reorder advertisements.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    setDeleteError(null)
    try {
      await api.deleteAdvertisement(deleteTarget.id)
      setDeleteTarget(null)
      await load()
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Could not delete advertisement.')
    } finally {
      setDeleting(false)
    }
  }

  async function handleFormSubmit(values: Parameters<typeof api.createAdvertisement>[0]) {
    if (formState?.mode === 'edit') {
      await api.updateAdvertisement(formState.ad.id, values)
    } else {
      await api.createAdvertisement(values)
    }
    setFormState(null)
    await load()
  }

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-ink">Advertisements</h1>
          <p className="mt-1 text-sm text-ink-muted">
            Controls the existing carousel in the Basseer app — publishing or deactivating here
            takes effect immediately, no app update needed.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setFormState({ mode: 'add' })}
          className="flex shrink-0 items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-sm font-semibold text-white hover:bg-accent-ink"
        >
          <Plus size={15} />
          Add advertisement
        </button>
      </div>

      {loadError && (
        <div className="mb-4 rounded-lg border border-danger/20 bg-danger-soft px-4 py-3 text-sm text-danger">
          {loadError}
        </div>
      )}

      {loading ? (
        <p className="text-sm text-ink-muted">Loading advertisements…</p>
      ) : ads.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-10 text-center text-sm text-ink-faint">
          No advertisements yet. Add one to start filling the Basseer carousel.
        </p>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-surface">
          <table className="w-full text-sm">
            <tbody>
              {ads.map((ad, index) => {
                const status = computeAdStatus(ad)
                const isBusy = busyId === ad.id
                return (
                  <tr key={ad.id} className={`border-b border-border last:border-0 ${isBusy ? 'opacity-50' : ''}`}>
                    <td className="w-16 px-3 py-3">
                      <div className="flex flex-col items-center gap-0.5">
                        <button
                          type="button"
                          disabled={index === 0 || isBusy}
                          onClick={() => handleMove(index, -1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move up"
                        >
                          <ChevronUp size={16} />
                        </button>
                        <button
                          type="button"
                          disabled={index === ads.length - 1 || isBusy}
                          onClick={() => handleMove(index, 1)}
                          className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                          aria-label="Move down"
                        >
                          <ChevronDown size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="px-2 py-3">
                      <img
                        src={ad.image_url}
                        alt=""
                        className="h-12 w-20 rounded-md border border-border object-cover"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <p dir="auto" className="font-medium text-ink">
                        {ad.title || <span className="text-ink-faint">Untitled</span>}
                      </p>
                      {ad.destination_url && (
                        <a
                          href={ad.destination_url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="mt-0.5 flex items-center gap-1 text-xs text-accent hover:underline"
                        >
                          <ExternalLink size={11} />
                          {ad.destination_url}
                        </a>
                      )}
                      <p className="mt-0.5 text-xs text-ink-faint">
                        {formatDate(ad.start_at)} – {formatDate(ad.end_at)}
                      </p>
                    </td>
                    <td className="px-2 py-3">
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${STATUS_STYLES[status]}`}
                      >
                        {STATUS_LABELS[status]}
                      </span>
                    </td>
                    <td className="px-2 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleToggleActive(ad)}
                          title={ad.is_active ? 'Deactivate' : 'Activate'}
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          {ad.is_active ? <EyeOff size={15} /> : <Eye size={15} />}
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => setFormState({ mode: 'edit', ad })}
                          title="Edit"
                          className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => {
                            setDeleteError(null)
                            setDeleteTarget(ad)
                          }}
                          title="Delete"
                          className="rounded-md p-1.5 text-ink-muted hover:bg-danger-soft hover:text-danger"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {formState && (
        <Modal
          title={formState.mode === 'edit' ? 'Edit advertisement' : 'Add advertisement'}
          onClose={() => setFormState(null)}
        >
          <AdvertisementForm
            initial={formState.mode === 'edit' ? formState.ad : null}
            nextSortOrder={1 + Math.max(0, ...ads.map((a) => a.sort_order))}
            onSubmit={handleFormSubmit}
            onCancel={() => setFormState(null)}
          />
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete advertisement?"
          message={`This permanently deletes "${deleteTarget.title || 'this advertisement'}". This can't be undone.`}
          confirmLabel="Delete"
          danger
          busy={deleting}
          errorMessage={deleteError}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  )
}
