import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  Plus,
  Pencil,
  Trash2,
  ChevronUp,
  ChevronDown,
  Eye,
  EyeOff,
  ImageOff,
} from 'lucide-react'
import type { ContentItem, ContentCategory } from '../../../types/content'
import { AUDIENCE_LABELS, CONTENT_TYPE_LABELS } from '../../../types/content'
import * as api from '../../../lib/contentApi'
import Modal from '../../../components/Modal'
import ConfirmDialog from '../../../components/ConfirmDialog'
import ContentItemForm from '../../../components/content/ContentItemForm'

type StatusFilter = 'all' | 'published' | 'draft'

export default function ItemsPanel() {
  const [categories, setCategories] = useState<ContentCategory[]>([])
  const [items, setItems] = useState<ContentItem[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')

  const [formState, setFormState] = useState<
    { mode: 'add' } | { mode: 'edit'; item: ContentItem } | null
  >(null)
  const [deleteTarget, setDeleteTarget] = useState<ContentItem | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      const [cats, its] = await Promise.all([api.listCategories(), api.listItems()])
      setCategories(cats)
      // Tips (content_type = 'tip') have their own dedicated tab with a
      // purpose-built editor and preview — kept out of this generic list
      // so the same item doesn't appear in two places.
      setItems(its.filter((item) => item.content_type !== 'tip'))
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load content.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const itemsByCategory = useMemo(() => {
    const map = new Map<string, ContentItem[]>()
    for (const item of items) {
      const list = map.get(item.category_id) ?? []
      list.push(item)
      map.set(item.category_id, list)
    }
    for (const list of map.values()) list.sort((a, b) => a.sort_order - b.sort_order)
    return map
  }, [items])

  function matchesFilters(item: ContentItem) {
    if (categoryFilter !== 'all' && item.category_id !== categoryFilter) return false
    if (statusFilter === 'published' && !item.is_published) return false
    if (statusFilter === 'draft' && item.is_published) return false
    return true
  }

  const visibleCategories = categories.filter((c) => {
    if (categoryFilter !== 'all' && c.id !== categoryFilter) return false
    const group = itemsByCategory.get(c.id) ?? []
    return group.some(matchesFilters)
  })

  async function handleTogglePublished(item: ContentItem) {
    setBusyId(item.id)
    try {
      await api.setItemPublished(item.id, !item.is_published)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not update content.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleMove(group: ContentItem[], index: number, direction: -1 | 1) {
    const other = group[index + direction]
    if (!other) return
    const current = group[index]
    setBusyId(current.id)
    try {
      await api.swapItemOrder(current, other)
      await load()
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not reorder content.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    setDeleteError(null)
    try {
      await api.deleteItem(deleteTarget.id)
      setDeleteTarget(null)
      await load()
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Could not delete content.')
    } finally {
      setDeleting(false)
    }
  }

  async function handleFormSubmit(values: Parameters<typeof api.createItem>[0]) {
    if (formState?.mode === 'edit') {
      await api.updateItem(formState.item.id, values)
    } else {
      await api.createItem(values)
    }
    setFormState(null)
    await load()
  }

  if (loading) {
    return <p className="text-sm text-ink-muted">Loading content…</p>
  }

  if (categories.length === 0) {
    return (
      <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-6 text-center text-sm text-ink-faint">
        Add a category first, in the Categories tab — content items need one to belong to.
      </p>
    )
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-ink focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          >
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {AUDIENCE_LABELS[c.audience]}
              </option>
            ))}
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
            className="rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-ink focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          >
            <option value="all">All statuses</option>
            <option value="published">Published</option>
            <option value="draft">Draft</option>
          </select>
        </div>
        <button
          type="button"
          onClick={() => setFormState({ mode: 'add' })}
          className="flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-white hover:bg-accent-ink"
        >
          <Plus size={14} />
          Add content
        </button>
      </div>

      {loadError && (
        <div className="rounded-lg border border-danger/20 bg-danger-soft px-4 py-3 text-sm text-danger">
          {loadError}
        </div>
      )}

      {visibleCategories.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border bg-surface px-4 py-6 text-center text-sm text-ink-faint">
          No content matches these filters yet.
        </p>
      ) : (
        <div className="space-y-6">
          {visibleCategories.map((category) => {
            const group = itemsByCategory.get(category.id) ?? []
            const visibleInGroup = group.filter(matchesFilters)
            return (
              <div key={category.id}>
                <h3 dir="auto" className="mb-2 text-sm font-bold text-ink">
                  {category.name}{' '}
                  <span className="font-normal text-ink-faint">
                    · {AUDIENCE_LABELS[category.audience]}
                  </span>
                </h3>
                <div className="overflow-hidden rounded-xl border border-border bg-surface">
                  <table className="w-full text-sm">
                    <tbody>
                      {visibleInGroup.map((item) => {
                        const indexInGroup = group.findIndex((g) => g.id === item.id)
                        const isBusy = busyId === item.id
                        return (
                          <tr
                            key={item.id}
                            className={`border-b border-border last:border-0 ${isBusy ? 'opacity-50' : ''}`}
                          >
                            <td className="w-16 px-3 py-3">
                              <div className="flex flex-col items-center gap-0.5">
                                <button
                                  type="button"
                                  disabled={indexInGroup === 0 || isBusy}
                                  onClick={() => handleMove(group, indexInGroup, -1)}
                                  className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                                  aria-label="Move up"
                                >
                                  <ChevronUp size={16} />
                                </button>
                                <button
                                  type="button"
                                  disabled={indexInGroup === group.length - 1 || isBusy}
                                  onClick={() => handleMove(group, indexInGroup, 1)}
                                  className="rounded p-0.5 text-ink-faint hover:bg-canvas hover:text-ink disabled:opacity-30"
                                  aria-label="Move down"
                                >
                                  <ChevronDown size={16} />
                                </button>
                              </div>
                            </td>
                            <td className="w-14 px-2 py-3">
                              {item.thumbnail_url ? (
                                <img
                                  src={item.thumbnail_url}
                                  alt=""
                                  className="h-10 w-10 rounded-lg border border-border object-cover"
                                />
                              ) : (
                                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-dashed border-border bg-canvas text-ink-faint">
                                  <ImageOff size={14} />
                                </div>
                              )}
                            </td>
                            <td className="px-2 py-3">
                              <p dir="auto" className="font-medium text-ink">
                                {item.title}
                              </p>
                              <p className="mt-0.5 text-xs text-ink-faint">
                                {CONTENT_TYPE_LABELS[item.content_type]}
                              </p>
                            </td>
                            <td className="px-2 py-3">
                              <span
                                className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                                  item.is_published
                                    ? 'bg-success-soft text-success'
                                    : 'bg-warning-soft text-warning'
                                }`}
                              >
                                {item.is_published ? 'Published' : 'Draft'}
                              </span>
                            </td>
                            <td className="px-2 py-3 text-right">
                              <div className="flex justify-end gap-1">
                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => handleTogglePublished(item)}
                                  title={item.is_published ? 'Unpublish' : 'Publish'}
                                  className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                                >
                                  {item.is_published ? <EyeOff size={15} /> : <Eye size={15} />}
                                </button>
                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => setFormState({ mode: 'edit', item })}
                                  title="Edit"
                                  className="rounded-md p-1.5 text-ink-muted hover:bg-canvas hover:text-ink"
                                >
                                  <Pencil size={15} />
                                </button>
                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => {
                                    setDeleteError(null)
                                    setDeleteTarget(item)
                                  }}
                                  title="Delete"
                                  className="rounded-md p-1.5 text-ink-muted hover:bg-danger-soft hover:text-danger"
                                >
                                  <Trash2 size={15} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {formState && (
        <Modal
          title={formState.mode === 'edit' ? 'Edit content' : 'Add content'}
          maxWidthClass="max-w-xl"
          onClose={() => setFormState(null)}
        >
          <ContentItemForm
            initial={formState.mode === 'edit' ? formState.item : null}
            categories={categories}
            defaultCategoryId={categoryFilter !== 'all' ? categoryFilter : undefined}
            nextSortOrder={
              1 +
              Math.max(
                0,
                ...(
                  itemsByCategory.get(
                    formState.mode === 'edit'
                      ? formState.item.category_id
                      : categoryFilter !== 'all'
                        ? categoryFilter
                        : (categories[0]?.id ?? ''),
                  ) ?? []
                ).map((i) => i.sort_order),
              )
            }
            onSubmit={handleFormSubmit}
            onCancel={() => setFormState(null)}
          />
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete content?"
          message={`This permanently deletes "${deleteTarget.title}". This can't be undone.`}
          confirmLabel="Delete"
          danger
          busy={deleting}
          errorMessage={deleteError}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  )
}
