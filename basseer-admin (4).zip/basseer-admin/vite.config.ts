import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Basseer Admin Dashboard — separate app from the Basseer user app.
// Talks to the SAME Supabase project via the public anon/publishable key only.
// See README.md for deployment notes.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174, // deliberately different from a typical user-app dev port (5173)
  },
})
