import { supabase } from './supabase'
import { optimizeImage } from './imageOptimize'
import type { Advertisement, AdvertisementInput } from '../types/advertisement'

const BUCKET = 'advertisements'
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024
const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp'])

function unwrap<T>({ data, error }: { data: T; error: { message: string } | null }): T {
  if (error) throw new Error(error.message)
  return data
}

export async function listAdvertisements(): Promise<Advertisement[]> {
  const res = await supabase
    .from('advertisements')
    .select('*')
    .order('sort_order', { ascending: true })
  return unwrap(res) ?? []
}

export async function createAdvertisement(input: AdvertisementInput): Promise<Advertisement> {
  const res = await supabase.from('advertisements').insert(input).select().single()
  return unwrap(res)
}

export async function updateAdvertisement(
  id: string,
  input: Partial<AdvertisementInput>,
): Promise<Advertisement> {
  const res = await supabase.from('advertisements').update(input).eq('id', id).select().maybeSingle()
  const row = unwrap(res)
  if (!row) {
    throw new Error("Couldn't save — this advertisement may have been changed or removed elsewhere.")
  }
  return row
}

export async function deleteAdvertisement(id: string): Promise<void> {
  const res = await supabase.from('advertisements').delete().eq('id', id).select()
  const rows = unwrap(res)
  if (!rows || rows.length === 0) {
    throw new Error("Couldn't delete — this advertisement may have already been removed.")
  }
}

export async function swapAdvertisementOrder(a: Advertisement, b: Advertisement): Promise<void> {
  unwrap(await supabase.from('advertisements').update({ sort_order: b.sort_order }).eq('id', a.id).select())
  unwrap(await supabase.from('advertisements').update({ sort_order: a.sort_order }).eq('id', b.id).select())
}

export async function uploadAdvertisementImage(file: File): Promise<string> {
  if (!ALLOWED_TYPES.has(file.type)) {
    throw new Error('Please choose a JPEG, PNG, or WebP image.')
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new Error('That image is larger than 5MB — please choose a smaller file.')
  }

  const optimized = await optimizeImage(file)

  const ext = optimized.name.split('.').pop()?.toLowerCase() || 'jpg'
  const path = `${crypto.randomUUID()}.${ext}`

  const { error } = await supabase.storage.from(BUCKET).upload(path, optimized, {
    cacheControl: '31536000',
    upsert: false,
    contentType: optimized.type,
  })
  if (error) throw new Error(error.message)

  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path)
  return data.publicUrl
}
