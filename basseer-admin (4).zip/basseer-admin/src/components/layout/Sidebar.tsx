import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  BookOpen,
  Megaphone,
  Building2,
  Users,
  ClipboardList,
  Settings,
  X,
} from 'lucide-react'
import { LogoMark } from '../Logo'

const NAV_ITEMS = [
  { to: '/', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/content', label: 'Content', icon: BookOpen, end: false },
  { to: '/advertisements', label: 'Advertisements', icon: Megaphone, end: false },
  { to: '/hospitals', label: 'Hospitals', icon: Building2, end: false },
  { to: '/users', label: 'Users', icon: Users, end: false },
  { to: '/assessments', label: 'Assessments', icon: ClipboardList, end: false },
  { to: '/settings', label: 'Settings', icon: Settings, end: false },
] as const

interface SidebarProps {
  mobileOpen: boolean
  onClose: () => void
}

export default function Sidebar({ mobileOpen, onClose }: SidebarProps) {
  return (
    <>
      {/* Backdrop, mobile only */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-ink/30 md:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-border bg-surface transition-transform duration-200 md:static md:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center justify-between px-5">
          <div className="flex items-center gap-2.5 text-ink">
            <LogoMark size={26} className="text-accent" />
            <div className="leading-tight">
              <p className="text-[15px] font-bold tracking-tight">Basseer</p>
              <p className="text-[11px] font-medium uppercase tracking-wider text-ink-faint">
                Admin
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-ink-muted hover:bg-canvas md:hidden"
            aria-label="Close navigation"
          >
            <X size={18} />
          </button>
        </div>

        <nav className="flex-1 space-y-0.5 px-3 py-2">
          {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-accent-soft text-accent-ink'
                    : 'text-ink-muted hover:bg-canvas hover:text-ink'
                }`
              }
            >
              <Icon size={18} strokeWidth={2} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-border px-4 py-4">
          <p className="text-xs leading-relaxed text-ink-faint">
            Foundation build — Users and Assessments modules ship in later tasks.
          </p>
        </div>
      </aside>
    </>
  )
}
