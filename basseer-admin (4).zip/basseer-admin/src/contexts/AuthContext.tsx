import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'
import type { AdminRoleName, AuthStatus } from '../types/admin'

interface AuthContextValue {
  status: AuthStatus
  session: Session | null
  roles: AdminRoleName[]
  errorMessage: string | null
  isSuperAdmin: boolean
  hasRole: (role: AdminRoleName) => boolean
  signOut: () => Promise<void>
  retry: () => void
}

export const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>('loading')
  const [session, setSession] = useState<Session | null>(null)
  const [roles, setRoles] = useState<AdminRoleName[]>([])
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  // Guards against a slow, stale request resolving after a newer one
  // (e.g. sign-out fired while the roles fetch for the previous session
  // was still in flight).
  const requestId = useRef(0)

  const resolveRoles = useCallback(async (activeSession: Session | null) => {
    const thisRequest = ++requestId.current

    if (!activeSession) {
      setStatus('unauthenticated')
      setRoles([])
      return
    }

    try {
      const { data, error } = await supabase
        .from('admin_roles')
        .select('role')
        .eq('user_id', activeSession.user.id)

      if (thisRequest !== requestId.current) return // superseded by a newer resolution

      if (error) {
        setStatus('error')
        setErrorMessage(
          'Could not verify admin access. This is usually a temporary connection issue.',
        )
        return
      }

      const resolvedRoles = (data ?? []).map((row) => row.role as AdminRoleName)

      if (resolvedRoles.length === 0) {
        setStatus('unauthorized')
        setRoles([])
      } else {
        setRoles(resolvedRoles)
        setStatus('authorized')
      }
    } catch {
      if (thisRequest !== requestId.current) return
      setStatus('error')
      setErrorMessage('Could not reach Basseer. Check your connection and try again.')
    }
  }, [])

  useEffect(() => {
    let isMounted = true

    supabase.auth.getSession().then(({ data }) => {
      if (!isMounted) return
      setSession(data.session)
      void resolveRoles(data.session)
    })

    const { data: subscription } = supabase.auth.onAuthStateChange((_event, newSession) => {
      if (!isMounted) return
      setSession(newSession)
      setErrorMessage(null)
      setStatus('loading')
      void resolveRoles(newSession)
    })

    return () => {
      isMounted = false
      subscription.subscription.unsubscribe()
    }
  }, [resolveRoles])

  const signOut = useCallback(async () => {
    await supabase.auth.signOut()
    // onAuthStateChange (SIGNED_OUT) drives the rest of the state reset.
  }, [])

  const retry = useCallback(() => {
    setStatus('loading')
    setErrorMessage(null)
    void resolveRoles(session)
  }, [resolveRoles, session])

  const hasRole = useCallback((role: AdminRoleName) => roles.includes(role), [roles])

  const value: AuthContextValue = {
    status,
    session,
    roles,
    errorMessage,
    isSuperAdmin: roles.includes('super_admin'),
    hasRole,
    signOut,
    retry,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider')
  return ctx
}
