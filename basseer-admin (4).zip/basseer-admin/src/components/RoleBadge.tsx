import type { AdminRoleName } from '../types/admin'

const ROLE_STYLES: Record<AdminRoleName, string> = {
  super_admin: 'bg-accent-soft text-accent-ink',
  content_editor: 'bg-success-soft text-success',
  support: 'bg-warning-soft text-warning',
}

const ROLE_LABELS: Record<AdminRoleName, string> = {
  super_admin: 'Super admin',
  content_editor: 'Content editor',
  support: 'Support',
}

export default function RoleBadge({ role }: { role: AdminRoleName }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${ROLE_STYLES[role]}`}
    >
      {ROLE_LABELS[role]}
    </span>
  )
}
