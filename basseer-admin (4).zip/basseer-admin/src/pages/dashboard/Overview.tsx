import { Users, Baby, ClipboardList, BookOpen, Megaphone } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import StatCard from '../../components/StatCard'
import RoleBadge from '../../components/RoleBadge'

export default function Overview() {
  const { session, roles } = useAuth()

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-6">
        <h1 className="text-xl font-bold tracking-tight text-ink">Overview</h1>
        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-sm text-ink-muted">
          <span>
            Signed in as <span className="font-medium text-ink">{session?.user.email}</span>
          </span>
          <div className="flex gap-1.5">
            {roles.map((role) => (
              <RoleBadge key={role} role={role} />
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="Users" value={null} icon={Users} hint="Ships with the Users module" />
        <StatCard
          label="Children"
          value={null}
          icon={Baby}
          hint="Ships with the Users module"
        />
        <StatCard
          label="Assessments"
          value={null}
          icon={ClipboardList}
          hint="Ships with the Assessments module"
        />
        <StatCard
          label="Content items"
          value={null}
          icon={BookOpen}
          hint="Ships with the Content module"
        />
        <StatCard
          label="Advertisements"
          value={null}
          icon={Megaphone}
          hint="Ships with the Advertisements module"
        />
      </div>

      <div className="mt-6 rounded-xl border border-border bg-surface p-5 shadow-card">
        <h2 className="text-sm font-bold text-ink">Foundation status</h2>
        <ul className="mt-3 space-y-2 text-sm text-ink-muted">
          <li className="flex items-start gap-2">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-success" />
            Admin authentication and role-based authorization are live and enforced by RLS.
          </li>
          <li className="flex items-start gap-2">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-success" />
            Every dashboard route is protected against unauthenticated and unauthorized access.
          </li>
          <li className="flex items-start gap-2">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-warning" />
            Content, Advertisements, Users, and Assessments management are not implemented yet —
            those are separate tasks.
          </li>
        </ul>
      </div>
    </div>
  )
}
