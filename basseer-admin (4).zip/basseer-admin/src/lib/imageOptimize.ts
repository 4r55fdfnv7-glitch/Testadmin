const MAX_DIMENSION = 1600
const JPEG_QUALITY = 0.85

/**
 * Downscales (if needed) and re-encodes an image as JPEG before upload, so
 * the Basseer carousel never has to load an oversized, unoptimized banner.
 * Falls back to the original file untouched if anything goes wrong — a
 * slightly-large image beats a failed upload.
 */
export async function optimizeImage(file: File): Promise<File> {
  try {
    const bitmap = await createImageBitmap(file)
    const scale = Math.min(1, MAX_DIMENSION / Math.max(bitmap.width, bitmap.height))
    const width = Math.round(bitmap.width * scale)
    const height = Math.round(bitmap.height * scale)

    const canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height
    const ctx = canvas.getContext('2d')
    if (!ctx) return file

    ctx.drawImage(bitmap, 0, 0, width, height)
    bitmap.close()

    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, 'image/jpeg', JPEG_QUALITY),
    )
    if (!blob) return file

    // Only use the optimized version if it's actually smaller — a tiny
    // source image re-encoded at quality 0.85 can occasionally grow.
    if (blob.size >= file.size) return file

    const newName = file.name.replace(/\.[^.]+$/, '') + '.jpg'
    return new File([blob], newName, { type: 'image/jpeg' })
  } catch {
    return file
  }
}
