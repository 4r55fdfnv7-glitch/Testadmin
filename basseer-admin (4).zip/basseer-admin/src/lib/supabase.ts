import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL
const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY

if (!url || !publishableKey) {
  // Fail loudly at boot rather than producing confusing downstream auth errors.
  throw new Error(
    'Missing Supabase configuration. Set VITE_SUPABASE_URL and ' +
      'VITE_SUPABASE_PUBLISHABLE_KEY in .env (see .env.example).',
  )
}

// SECURITY: this must only ever be the public anon/publishable key.
// Authorization for admin actions is enforced by RLS + admin_roles on the
// database side (see supabase/migrations/20260821214704_admin_roles_foundation.sql),
// never by anything in this client bundle. A service_role key must NEVER be
// added here, to any .env file read by the browser, or to any client bundle —
// privileged operations belong in a Supabase Edge Function instead.
export const supabase = createClient(url, publishableKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
})
