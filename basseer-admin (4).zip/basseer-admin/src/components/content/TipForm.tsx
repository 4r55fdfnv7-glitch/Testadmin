import { useState, type ChangeEvent, type FormEvent } from 'react'
import { Upload, Eye } from 'lucide-react'
import type { ContentItem, ContentItemInput, ContentCategory } from '../../types/content'
import { AUDIENCE_LABELS } from '../../types/content'
import { uploadThumbnail } from '../../lib/contentApi'
import Modal from '../Modal'
import TipPreview from './TipPreview'

interface TipFormProps {
  initial?: ContentItem | null
  categories: ContentCategory[]
  nextSortOrder: number
  onSubmit: (values: ContentItemInput) => Promise<void>
  onCancel: () => void
}

export default function TipForm({ initial, categories, nextSortOrder, onSubmit, onCancel }: TipFormProps) {
  const [title, setTitle] = useState(initial?.title ?? '')
  const [summary, setSummary] = useState(initial?.description ?? '')
  const [fullContent, setFullContent] = useState(initial?.full_content ?? '')
  const [categoryId, setCategoryId] = useState(initial?.category_id ?? categories[0]?.id ?? '')
  const [imageUrl, setImageUrl] = useState(initial?.thumbnail_url ?? '')
  const [isPublished, setIsPublished] = useState(initial?.is_published ?? false)
  const [sortOrder, setSortOrder] = useState(initial?.sort_order ?? nextSortOrder)
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError(null)
    try {
      setImageUrl(await uploadThumbnail(file))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed. Please try again.')
    } finally {
      setUploading(false)
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!title.trim()) {
      setError('Title is required.')
      return
    }
    if (!categoryId) {
      setError('Choose a category — add one in the Categories tab first.')
      return
    }
    setSubmitting(true)
    setError(null)
    try {
      await onSubmit({
        category_id: categoryId,
        title: title.trim(),
        description: summary.trim() || null,
        full_content: fullContent.trim() || null,
        content_type: 'tip',
        content_url: null,
        thumbnail_url: imageUrl.trim() || null,
        sort_order: sortOrder,
        is_published: isPublished,
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-warning/30 bg-warning-soft px-3.5 py-2.5 text-xs text-warning">
        Educational content only — not a diagnosis, treatment, or guaranteed outcome. You're
        responsible for what's published here.
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Title</label>
          <input
            dir="auto"
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Short summary</label>
          <textarea
            dir="auto"
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            rows={2}
            placeholder="Shown collapsed, before the tip is expanded"
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Full content</label>
          <textarea
            dir="auto"
            value={fullContent}
            onChange={(e) => setFullContent(e.target.value)}
            rows={6}
            placeholder="Shown when the tip is expanded. Plain text — line breaks are preserved."
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Category</label>
          {categories.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border bg-canvas px-3.5 py-2.5 text-sm text-ink-faint">
              No categories yet — add one in the Categories tab first.
            </p>
          ) : (
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} · {AUDIENCE_LABELS[c.audience]}
                </option>
              ))}
            </select>
          )}
          <p className="mt-1 text-xs text-ink-faint">The tip's audience follows its category's audience.</p>
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Image (optional)</label>
          <div className="flex items-center gap-3">
            {imageUrl ? (
              <img src={imageUrl} alt="" className="h-14 w-14 shrink-0 rounded-lg border border-border object-cover" />
            ) : (
              <div className="h-14 w-14 shrink-0 rounded-lg border border-dashed border-border bg-canvas" />
            )}
            <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-ink hover:bg-canvas">
              <Upload size={14} />
              {uploading ? 'Uploading…' : imageUrl ? 'Replace image' : 'Upload image'}
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={handleFileChange}
                disabled={uploading}
              />
            </label>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-ink">Sort order</label>
            <input
              type="number"
              value={sortOrder}
              onChange={(e) => setSortOrder(Number(e.target.value))}
              className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
            />
          </div>
          <div className="flex items-end pb-2.5">
            <label className="flex items-center gap-2 text-sm font-medium text-ink">
              <input
                type="checkbox"
                checked={isPublished}
                onChange={(e) => setIsPublished(e.target.checked)}
                className="h-4 w-4 rounded border-border text-accent focus:ring-accent"
              />
              Published
            </label>
          </div>
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <div className="flex items-center justify-between gap-2 pt-2">
          <button
            type="button"
            onClick={() => setShowPreview(true)}
            className="flex items-center gap-1.5 rounded-lg border border-border px-3.5 py-2 text-sm font-semibold text-ink hover:bg-canvas"
          >
            <Eye size={15} />
            Preview
          </button>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onCancel}
              className="rounded-lg border border-border px-4 py-2 text-sm font-semibold text-ink hover:bg-canvas"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || uploading || categories.length === 0}
              className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white hover:bg-accent-ink disabled:opacity-60"
            >
              {submitting ? 'Saving…' : initial ? 'Save changes' : 'Add tip'}
            </button>
          </div>
        </div>
      </form>

      {showPreview && (
        <Modal title="Preview" onClose={() => setShowPreview(false)}>
          <TipPreview title={title} summary={summary || null} fullContent={fullContent || null} imageUrl={imageUrl || null} />
        </Modal>
      )}
    </div>
  )
}
