import { Settings as SettingsIcon } from 'lucide-react'
import ComingSoon from '../../components/ComingSoon'

export default function Settings() {
  return (
    <ComingSoon
      icon={SettingsIcon}
      title="System settings will be available here"
      description="Platform-wide configuration is a separate task, scoped once the other modules define what needs to be configurable."
    />
  )
}
