import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="text-sm font-semibold text-ink-faint">404</p>
      <h1 className="mt-2 text-lg font-bold text-ink">Page not found</h1>
      <p className="mt-1 text-sm text-ink-muted">That admin page doesn't exist.</p>
      <Link
        to="/"
        className="mt-5 rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white hover:bg-accent-ink"
      >
        Back to dashboard
      </Link>
    </div>
  )
}
