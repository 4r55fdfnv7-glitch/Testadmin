import { useState, type ChangeEvent, type FormEvent } from 'react'
import { Upload } from 'lucide-react'
import type { Advertisement, AdvertisementInput } from '../../types/advertisement'
import { uploadAdvertisementImage } from '../../lib/advertisementApi'
import { validateSafeUrl } from '../../lib/urlValidation'

interface AdvertisementFormProps {
  initial?: Advertisement | null
  nextSortOrder: number
  onSubmit: (values: AdvertisementInput) => Promise<void>
  onCancel: () => void
}

// datetime-local inputs need "YYYY-MM-DDTHH:mm" in *local* time, with no
// timezone suffix. Converting an ISO timestamp straight to that format
// avoids a UTC/local mismatch that would otherwise shift the displayed time.
function toDatetimeLocal(iso: string): string {
  const d = new Date(iso)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function defaultStart(): string {
  return toDatetimeLocal(new Date().toISOString())
}

function defaultEnd(): string {
  const d = new Date()
  d.setDate(d.getDate() + 30)
  return toDatetimeLocal(d.toISOString())
}

export default function AdvertisementForm({
  initial,
  nextSortOrder,
  onSubmit,
  onCancel,
}: AdvertisementFormProps) {
  const [imageUrl, setImageUrl] = useState(initial?.image_url ?? '')
  const [title, setTitle] = useState(initial?.title ?? '')
  const [destinationUrl, setDestinationUrl] = useState(initial?.destination_url ?? '')
  const [startAt, setStartAt] = useState(initial ? toDatetimeLocal(initial.start_at) : defaultStart())
  const [endAt, setEndAt] = useState(initial ? toDatetimeLocal(initial.end_at) : defaultEnd())
  const [isActive, setIsActive] = useState(initial?.is_active ?? false)
  const [sortOrder, setSortOrder] = useState(initial?.sort_order ?? nextSortOrder)
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError(null)
    try {
      const url = await uploadAdvertisementImage(file)
      setImageUrl(url)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed. Please try again.')
    } finally {
      setUploading(false)
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()

    if (!imageUrl.trim()) {
      setError('Upload an image — every advertisement needs one.')
      return
    }
    const urlCheck = validateSafeUrl(destinationUrl)
    if (!urlCheck.valid) {
      setError(urlCheck.reason)
      return
    }
    const startDate = new Date(startAt)
    const endDate = new Date(endAt)
    if (endDate <= startDate) {
      setError('End date must be after the start date.')
      return
    }

    setSubmitting(true)
    setError(null)
    try {
      await onSubmit({
        image_url: imageUrl.trim(),
        title: title.trim() || null,
        destination_url: destinationUrl.trim() || null,
        start_at: startDate.toISOString(),
        end_at: endDate.toISOString(),
        is_active: isActive,
        sort_order: sortOrder,
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="mb-1.5 block text-sm font-medium text-ink">Image</label>
        <div className="flex items-center gap-3">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt=""
              className="h-16 w-28 shrink-0 rounded-lg border border-border object-cover"
            />
          ) : (
            <div className="h-16 w-28 shrink-0 rounded-lg border border-dashed border-border bg-canvas" />
          )}
          <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-ink hover:bg-canvas">
            <Upload size={14} />
            {uploading ? 'Uploading…' : imageUrl ? 'Replace image' : 'Upload image'}
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleFileChange}
              disabled={uploading}
            />
          </label>
        </div>
        <p className="mt-1.5 text-xs text-ink-faint">JPEG, PNG, or WebP, up to 5MB. Optimized automatically.</p>
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ink">Title (optional)</label>
        <input
          dir="auto"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          placeholder="Internal label — not necessarily shown in the carousel"
        />
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ink">Destination URL (optional)</label>
        <input
          value={destinationUrl}
          onChange={(e) => setDestinationUrl(e.target.value)}
          placeholder="https://…"
          className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
        />
        <p className="mt-1 text-xs text-ink-faint">Only plain http:// or https:// links are accepted.</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Starts</label>
          <input
            type="datetime-local"
            value={startAt}
            onChange={(e) => setStartAt(e.target.value)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Ends</label>
          <input
            type="datetime-local"
            value={endAt}
            onChange={(e) => setEndAt(e.target.value)}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ink">Sort order</label>
          <input
            type="number"
            value={sortOrder}
            onChange={(e) => setSortOrder(Number(e.target.value))}
            className="w-full rounded-lg border border-border px-3.5 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
        <div className="flex items-end pb-2.5">
          <label className="flex items-center gap-2 text-sm font-medium text-ink">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="h-4 w-4 rounded border-border text-accent focus:ring-accent"
            />
            Active
          </label>
        </div>
      </div>
      <p className="-mt-2 text-xs text-ink-faint">
        Active only shows the ad while today falls between the start and end dates — it still won't
        appear if that window hasn't started yet or has already passed.
      </p>

      {error && <p className="text-sm text-danger">{error}</p>}

      <div className="flex justify-end gap-2 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-border px-4 py-2 text-sm font-semibold text-ink hover:bg-canvas"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={submitting || uploading}
          className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white hover:bg-accent-ink disabled:opacity-60"
        >
          {submitting ? 'Saving…' : initial ? 'Save changes' : 'Add advertisement'}
        </button>
      </div>
    </form>
  )
}
