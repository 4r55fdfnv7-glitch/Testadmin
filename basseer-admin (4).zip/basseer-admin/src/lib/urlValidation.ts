/**
 * Validates a destination URL is a plain http(s) link. Mirrors the database's
 * own CHECK constraint (advertisements_destination_url_format: `^https?://`)
 * so the admin gets an immediate, specific error instead of a generic
 * "insert failed" message — the database is still the real enforcement.
 */
export function validateSafeUrl(value: string): { valid: true } | { valid: false; reason: string } {
  const trimmed = value.trim()
  if (trimmed === '') return { valid: true } // optional field — empty is fine

  const dangerousScheme = /^\s*(javascript|data|vbscript|file):/i
  if (dangerousScheme.test(trimmed)) {
    return { valid: false, reason: 'That URL scheme is not allowed. Use a plain http:// or https:// link.' }
  }

  if (!/^https?:\/\//i.test(trimmed)) {
    return { valid: false, reason: 'The URL must start with http:// or https://.' }
  }

  try {
    // Throws on a genuinely malformed URL (e.g. "https://" with nothing after it).
    new URL(trimmed)
  } catch {
    return { valid: false, reason: "That doesn't look like a valid URL." }
  }

  return { valid: true }
}
