import { useEffect, useState, type FormEvent } from 'react'
import { Navigate, useSearchParams } from 'react-router-dom'
import { AlertCircle } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'
import { LogoMark } from '../components/Logo'

export default function Login() {
  const { status } = useAuth()
  const [searchParams] = useSearchParams()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)
  const [sessionExpiredNotice, setSessionExpiredNotice] = useState(false)

  useEffect(() => {
    if (searchParams.get('reason') === 'expired') {
      setSessionExpiredNotice(true)
    }
  }, [searchParams])

  // Already signed in (any state but 'loading'/'unauthenticated') — let
  // ProtectedRoute at "/" decide what to show instead of duplicating that
  // logic here.
  if (status === 'authorized' || status === 'unauthorized' || status === 'error') {
    return <Navigate to="/" replace />
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setFormError(null)
    setSubmitting(true)

    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      if (error.message.toLowerCase().includes('invalid login credentials')) {
        setFormError('Incorrect email or password.')
      } else if (error.message.toLowerCase().includes('fetch')) {
        setFormError('Could not reach Basseer. Check your connection and try again.')
      } else {
        setFormError('Something went wrong signing you in. Please try again.')
      }
      setSubmitting(false)
      return
    }
    // On success, onAuthStateChange updates auth status and this component
    // re-renders into the <Navigate> branch above.
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <LogoMark size={40} className="text-accent" />
          <h1 className="mt-4 text-xl font-bold tracking-tight text-ink">Basseer Admin</h1>
          <p className="mt-1 text-sm text-ink-muted">Sign in to manage the Basseer platform.</p>
        </div>

        {sessionExpiredNotice && (
          <div className="mb-4 flex items-start gap-2 rounded-lg border border-warning/30 bg-warning-soft px-3.5 py-3 text-sm text-warning">
            <AlertCircle size={16} className="mt-0.5 shrink-0" />
            <span>Your session expired. Please sign in again.</span>
          </div>
        )}

        <form
          onSubmit={handleSubmit}
          className="rounded-xl border border-border bg-surface p-6 shadow-card"
        >
          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-ink">
                Email
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-faint focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
                placeholder="you@basseer.app"
              />
            </div>

            <div>
              <label htmlFor="password" className="mb-1.5 block text-sm font-medium text-ink">
                Password
              </label>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-faint focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
                placeholder="••••••••"
              />
            </div>
          </div>

          {formError && (
            <div className="mt-4 flex items-start gap-2 rounded-lg border border-danger/20 bg-danger-soft px-3.5 py-3 text-sm text-danger">
              <AlertCircle size={16} className="mt-0.5 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="mt-5 w-full rounded-lg bg-accent px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-accent-ink disabled:cursor-not-allowed disabled:opacity-60"
          >
            {submitting ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-ink-faint">
          Admin access only. This is not the Basseer app for families.
        </p>
      </div>
    </div>
  )
}
